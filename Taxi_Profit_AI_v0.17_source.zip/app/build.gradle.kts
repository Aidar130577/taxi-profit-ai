plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "kz.taxiprofitai"
    compileSdk = 35
    defaultConfig {
        applicationId = "kz.taxiprofitai"
        minSdk = 26
        targetSdk = 34
        versionCode = 17
        versionName = "0.17.0-approved-overlays"
    }
    buildFeatures { aidl = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.maplibre.gl:android-sdk:11.8.0") }
