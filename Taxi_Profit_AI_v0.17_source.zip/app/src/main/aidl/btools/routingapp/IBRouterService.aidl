package btools.routingapp;

// Public BRouter external-service AIDL contract, abrensch/brouter, MIT.
// Keep exactly the same package and method signature for IPC compatibility.
interface IBRouterService {
    String getTrackFromParams(in Bundle params);
}
