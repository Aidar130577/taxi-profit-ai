package kz.taxiprofitai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local test notebook. No passenger names, pickup/destination addresses, phone numbers or GPS are saved. */
data class LocalTrial(
    val id: Long,
    val tariff: String,
    val forecastGross: Double,
    val km: Double,
    val minutes: Double,
    val createdAtMs: Long,
    val demandLabel: String,
    val actualGross: Double? = null,
    val latencyMs: Long? = null
)

object TrialStore {
    private const val NAME = "taxi_profit_trial_log"
    private const val KEY = "trials"
    private const val LIMIT = 50

    @Synchronized fun read(context: Context): List<LocalTrial> {
        val src = context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(KEY,"[]") ?: "[]"
        val data = runCatching { JSONArray(src) }.getOrElse { JSONArray() }
        val rows = mutableListOf<LocalTrial>()
        for (i in 0 until data.length()) {
            val obj = data.optJSONObject(i) ?: continue
            val row = runCatching {
                LocalTrial(
                    obj.getLong("id"),obj.getString("tariff"),obj.getDouble("forecast"),
                    obj.getDouble("km"),obj.getDouble("minutes"),obj.getLong("date"),
                    obj.optString("demand","—"),
                    if (obj.has("actual") && !obj.isNull("actual")) obj.getDouble("actual") else null,
                    if (obj.has("latencyMs")) obj.getLong("latencyMs") else null
                )
            }.getOrNull()
            if (row != null && row.forecastGross.isFinite() && row.forecastGross >= 0) rows.add(row)
        }
        return rows.sortedByDescending { it.createdAtMs }
    }

    @Synchronized fun append(context: Context, tariff: String, result: LiveFareEstimate,
                             demand: String, latencyMs: Long): Long {
        val now=System.currentTimeMillis()
        val old=read(context)
        val id=now + old.count { it.id == now }
        val row=LocalTrial(id,tariff,result.gross,result.km,result.minutes,now,demand,
            latencyMs=latencyMs.coerceAtLeast(0L))
        write(context,(listOf(row)+old).take(LIMIT))
        return id
    }

    @Synchronized fun setActual(context: Context, id: Long, amount: Double): Boolean {
        if (!amount.isFinite() || amount <= 0.0) return false
        val old=read(context)
        if (old.none{it.id==id}) return false
        write(context,old.map {if(it.id==id) it.copy(actualGross=amount) else it})
        return true
    }
    private fun write(context: Context, rows: List<LocalTrial>) {
        val a=JSONArray()
        for (r in rows.take(LIMIT)) {
            val j=JSONObject()
                .put("id",r.id).put("tariff",r.tariff)
                .put("forecast",r.forecastGross).put("km",r.km)
                .put("minutes",r.minutes).put("date",r.createdAtMs)
                .put("demand",r.demandLabel)
            if (r.actualGross != null) j.put("actual",r.actualGross)
            if (r.latencyMs != null) j.put("latencyMs",r.latencyMs)
            a.put(j)
        }
        context.getSharedPreferences(NAME,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()
    }
}
