package kz.taxiprofitai

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.*

/** Manual diagnostics of actual BRouter route, separate from the overlay. */
class RouteTestActivity: Activity() {
    private lateinit var pipeline: OfflineRoutePipeline
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pipeline=OfflineRoutePipeline(this)
        val wrap=ScrollView(this)
        val col=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(24,28,24,28);setBackgroundColor(Color.WHITE)}
        fun label(s:String) = TextView(this).apply{text=s;textSize=16f;setTextColor(Color.BLACK);setPadding(0,15,0,5)}.also{col.addView(it)}
        fun edit(value:String) = EditText(this).apply {setSingleLine(false);setText(value);textSize=16f}.also{col.addView(it)}
        label("Проверка реального маршрутизатора BRouter")
        label("Точка А (адрес Алматы или '43.25000,76.90000')")
        val a=edit("проспект Абая, 164/8")
        label("Точка Б")
        val b=edit("улица Ади Шарипова, 72")
        label("Тариф")
        val tariff=Spinner(this).apply{adapter=ArrayAdapter(this@RouteTestActivity,android.R.layout.simple_spinner_dropdown_item,TarifCatalog.titles)}
        tariff.setSelection(TarifCatalog.titles.indexOf("Комфорт+"))
        col.addView(tariff)
        label("Надбавка, ₸ (0, если её нет)")
        val extra=edit("250")
        val result=TextView(this).apply{textSize=17f;setTextColor(Color.BLACK);setPadding(0,20,0,20);text="Пока нет маршрута."}
        col.addView(Button(this).apply {
            text="Проверить настоящий маршрут"
            setOnClickListener {
                result.text="Ищем адреса и обращаемся к локальной службе BRouter..."
                val name=tariff.selectedItem.toString()
                val demand=extra.text.toString().replace(',','.').toDoubleOrNull()
                if(demand==null||demand<0) {result.text="Некорректная надбавка";return@setOnClickListener}
                pipeline.calculate(a.text.toString(),b.text.toString()) { r ->
                    r.fold(onSuccess={ route ->
                        val t=TarifCatalog.forName(name)!!
                        val p=getSharedPreferences("taxi_profit_settings",MODE_PRIVATE)
                        val y=CommissionSettings.percent(p,name)
                        val park=CommissionSettings.park(p)
                        val calc=RouteFareEstimator.calculateWithCommission(t,route,Demand(DemandType.FIXED_ADD,demand,true),
                            y,park,CommissionSettings.loyalty(p))
                        val netText=calc.net?.let {FareEngine.kzt(it)}?:"— (ставка Яндекса не указана)"
                        val pctLabel=calc.commission?.effectiveYandexPct?.let {"%.2f%%".format(java.util.Locale.US,it)}?:"неизвестна"
                        result.text="BRouter: %.2f км / %.1f мин\nПрогноз стоимости: %s\nКомиссия Яндекса для $name: $pctLabel\nПосле комиссий: %s\n\nБЕЗ живых пробок и без автоматической платной подачи.\nСтавки Яндекса и стоимость поездки требуют проверки.".format(
                            java.util.Locale("ru","KZ"),route.km,route.minutes,FareEngine.kzt(calc.gross),netText)
                    },onFailure={result.text="Маршрут не получен: ${it.message}\n\nПроверь установленный BRouter, автомобильный профиль и скачанные сегменты rd5. Геокодер Android тоже может быть недоступен."})
                }
            }
        })
        col.addView(result)
        wrap.addView(col)
        setContentView(wrap)
    }
    override fun onDestroy() {pipeline.close();super.onDestroy()}
}
