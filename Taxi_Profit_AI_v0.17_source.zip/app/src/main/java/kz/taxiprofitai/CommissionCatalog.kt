package kz.taxiprofitai

import kotlin.math.min

/** Public figures are reference points, not a live Yandex commission feed.
 *  Each category has an INDEPENDENT commission setting. Values may depend on
 *  driver's loyalty level, high demand, local taxes and pass-through charges.
 */
enum class CommissionEvidence { OBSERVED_IN_RIDES, USER_REPORTED, PROVISIONAL, UNKNOWN }
data class CommissionProfile(
    val tariff:String,
    val referencePct:Double?,
    val evidence:CommissionEvidence,
    val explanation:String
)
data class CommissionBreakdown(
    val gross:Double,
    val yandexBase:Double?,
    val effectiveYandexPct:Double?,
    val yandexFee:Double?,
    val parkFee:Double,
    val net:Double?,
    val surgeExemptionApplied:Boolean
)

object CommissionCatalog {
    // User-provided Almaty rates confirmed in this chat on 2026-11-24.
    // The figures are user-reported settings, NOT independently verified Yandex rates.
    // Each can be edited individually. Loyalty discounts may change the effective rate.
    val profiles:List<CommissionProfile> = listOf(
        CommissionProfile("Эконом",17.1,CommissionEvidence.USER_REPORTED,"17,1% с НДС подтверждены пользователем из Яндекс Про"),
        CommissionProfile("Комфорт",19.2,CommissionEvidence.USER_REPORTED,"19,2% с НДС подтверждены пользователем из Яндекс Про"),
        CommissionProfile("Комфорт+",19.2,CommissionEvidence.USER_REPORTED,"19,2% с НДС подтверждены пользователем из Яндекс Про"),
        CommissionProfile("Электро",19.2,CommissionEvidence.PROVISIONAL,"Рабочая ставка 19,2% по прежнему указанию, поездки EV лично не проверены"),
        CommissionProfile("Business",19.2,CommissionEvidence.OBSERVED_IN_RIDES,"19,2% с НДС по данным Яндекс Про и детализации завершённых заказов"),
        CommissionProfile("Premier",19.2,CommissionEvidence.PROVISIONAL,"Рабочая ставка 19,2% по прежнему указанию, поездки PR лично не проверены")
    )
    private val byName = profiles.associateBy { it.tariff }
    fun forTariff(tariff:String):CommissionProfile =
        byName[tariff] ?: throw IllegalArgumentException("Unknown passenger tariff: $tariff")

    /** A Champion/Legend discount subtracts 3/8 PERCENTAGE POINTS per Yandex Pro docs.
     * Does not modify taxi park commission. Unknown percentage must stay unknown.
     */
    fun effectiveRate(basePct:Double?, loyaltyDiscountPoints:Double):Double? {
        require(loyaltyDiscountPoints in listOf(0.0,3.0,8.0))
        if(basePct==null) return null
        require(basePct.isFinite() && basePct in 0.0..100.0)
        return (basePct-loyaltyDiscountPoints).coerceAtLeast(0.0)
    }

    /**
     * For a verified purple banner "Очень высокий спрос. Комиссия снижена", Yandex
     * describes an exemption above 2x the base passenger fare. If the marker
     * isn't visible we DO NOT infer the discount from a guessed demand number.
     * Optional pass-through charges are excluded ONLY if separately verified.
     * Figures before individual rounding can differ from Yandex by ~1-2 KZT.
     */
    fun calculate(
        gross:Double, basePassengerFare:Double, yandexPct:Double?, parkPct:Double,
        loyaltyDiscountPoints:Double=0.0, verifiedHighDemandBanner:Boolean=false,
        verifiedPassThroughFees:Double=0.0
    ):CommissionBreakdown {
        require(gross.isFinite() && basePassengerFare.isFinite() &&
            gross>=0.0 && basePassengerFare>=0.0)
        require(parkPct.isFinite() && parkPct in 0.0..100.0)
        require(verifiedPassThroughFees.isFinite() && verifiedPassThroughFees>=0.0 && verifiedPassThroughFees<=gross)
        val effective=effectiveRate(yandexPct,loyaltyDiscountPoints)
        val commissionable=(gross-verifiedPassThroughFees).coerceAtLeast(0.0)
        val exempt=verifiedHighDemandBanner && commissionable>basePassengerFare*2
        val serviceBase=if(exempt) min(commissionable,basePassengerFare*2) else commissionable
        val yandexFee=effective?.let {serviceBase*it/100.0}
        // Default model: park fee on same chargeable amount; configurable percentage.
        val parkFee=commissionable*parkPct/100.0
        return CommissionBreakdown(gross,if(effective==null)null else serviceBase,effective,
            yandexFee,parkFee, yandexFee?.let {gross-it-parkFee},exempt)
    }
}
