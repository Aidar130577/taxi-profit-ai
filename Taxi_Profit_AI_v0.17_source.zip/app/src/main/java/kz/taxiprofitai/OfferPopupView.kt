package kz.taxiprofitai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** Approved 240×104 fare overlay; separate from persistent radar. */
class OfferPopupView(context:Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var title="Заказ";private var demandText="—";private var gross="СТОИМОСТЬ —";private var net="НА РУКИ —"
    private val yellow=Color.rgb(255,225,0);private val green=Color.rgb(162,255,151);private val purple=Color.rgb(184,116,255)
    private val density=resources.displayMetrics.density
    init {isClickable=true;importantForAccessibility=IMPORTANT_FOR_ACCESSIBILITY_YES}
    override fun onMeasure(w:Int,h:Int){val width=resolveSize((240*density).toInt(),w);setMeasuredDimension(width,resolveSize((104f*width/240f).toInt(),h))}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean,align:Paint.Align,maxWidth:Float,stretch:Boolean=false){
        paint.style=Paint.Style.FILL;paint.color=color;paint.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;paint.textSize=size;paint.textAlign=align;paint.textScaleX=1f
        val w=paint.measureText(s);if(w>0 && (stretch||w>maxWidth))paint.textScaleX=maxWidth/w
        c.drawText(s,x,y,paint);paint.textScaleX=1f
    }
    private fun line(c:Canvas,y:Float){paint.style=Paint.Style.STROKE;paint.color=Color.WHITE;paint.strokeWidth=.8f;c.drawLine(3f,y,237f,y,paint)}
    override fun onDraw(c:Canvas){
        super.onDraw(c);c.save();c.scale(width/240f,height/104f)
        paint.style=Paint.Style.FILL;paint.color=Color.rgb(22,32,39);c.drawRoundRect(RectF(1f,1f,239f,103f),7f,7f,paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=yellow;c.drawRoundRect(RectF(1f,1f,239f,103f),7f,7f,paint)
        text(c,title,6f,23f,18f,Color.WHITE,true,Paint.Align.LEFT,139f)
        text(c,demandText,234f,23f,18f,purple,true,Paint.Align.RIGHT,86f)
        line(c,29f);text(c,gross,120f,47f,18f,yellow,true,Paint.Align.CENTER,230f,true)
        text(c,net,120f,74f,25f,green,true,Paint.Align.CENTER,230f,true)
        line(c,78f);text(c,"Нажмите, чтобы скрыть",120f,96f,14f,Color.WHITE,false,Paint.Align.CENTER,228f)
        c.restore()
    }
    fun showQuote(tariff:String,demand:String,estimate:LiveFareEstimate?,status:String,ratesExpired:Boolean,parkPct:Double){
        title=when(tariff){"BS"->"Business BS";"EK"->"Economy EK";"K"->"Comfort K";"K+"->"Comfort K+";"EV"->"Electric EV";"PR"->"Premier PR";else->tariff}
        demandText=if(demand.startsWith("+"))demand else "—"
        val quote=NetQuotePresenter.present(estimate,parkPct)
        gross="СТОИМОСТЬ ${quote.grossText}${if(ratesExpired && estimate!=null)"*" else ""}"
        net="НА РУКИ ${quote.takeHomeText}"
        contentDescription="$title $demandText. $gross. $net. $status. Нажмите, чтобы скрыть."
        invalidate()
    }
}
