package kz.taxiprofitai

import java.math.BigDecimal
import java.util.Locale
import kotlin.math.roundToLong

/** Formats the two numbers shown in the order overlay. Never labels post-Yandex
 * income as "на руки" when the taxi-park deduction was not applied.
 */
data class NetQuotePresentation(
    val grossText: String,
    val takeHomeText: String,
    val commissionLine: String,
    val netKnown: Boolean
)
object NetQuotePresenter {
    private fun amount(value: Double): String =
        String.format(Locale.US, "%,d", value.roundToLong()).replace(',', ' ') + " ₸"

    private fun percent(value: Double?): String = when {
        value == null || !value.isFinite() -> "—"
        else -> BigDecimal.valueOf(value).stripTrailingZeros().toPlainString().replace('.', ',') + "%"
    }

    fun present(estimate: LiveFareEstimate?, parkPct: Double): NetQuotePresentation {
        require(parkPct.isFinite() && parkPct in 0.0..100.0)
        val net = estimate?.net
        val gross = estimate?.gross
        return NetQuotePresentation(
            grossText=if(gross != null) "≈ ${amount(gross)}" else "—",
            takeHomeText=if(net != null) "≈ ${amount(net)}" else "—",
            commissionLine="Яндекс ${percent(estimate?.commission?.effectiveYandexPct)} · парк ${percent(parkPct)}",
            netKnown=net != null
        )
    }
}
