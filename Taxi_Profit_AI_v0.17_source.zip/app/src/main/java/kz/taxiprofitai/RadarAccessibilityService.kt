package kz.taxiprofitai

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

/** User-enabled, read-only overlay. Does NOT click or alter Yandex Pro, use hidden APIs, or capture raw screenshots. */
class RadarAccessibilityService: AccessibilityService() {
    private val ui=Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("taxi_profit_settings",MODE_PRIVATE) }
    private val radar=RadarMemory()
    private lateinit var routePipeline: OfflineRoutePipeline
    private var routeKey: String? = null
    private var estimate: LiveFareEstimate? = null
    private var routeStatus: String = ""

    private lateinit var windows: WindowManager
    private var badge: RadarPanelView?=null
    private var params: WindowManager.LayoutParams?=null
    private var lastScan=0L
    private var lastRadar=0L
    private var detected=OrderTextParser.Detected(false,null,null,false,null,null,null,null)
    private val offerPopupState=OfferPopupState()
    private var popup: OfferPopupView?=null
    private var popupParams: WindowManager.LayoutParams?=null
    private var popupDragged=false
    private var nonOrderSnapshots=0
    private fun dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()
    private var running=false
    private var panelScale=1f
    private val ticker=object:Runnable { override fun run(){ if(running){render();ui.postDelayed(this,1000L)} } }
    private val settingsListener=android.content.SharedPreferences.OnSharedPreferenceChangeListener { _,key ->
        if(key=="shift_active") { if(prefs.getBoolean("shift_active",false)) startShift() else stopShift() }
        else if(running && (key?.startsWith("tariff_")==true || key=="airport"))render()
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        windows=getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(settingsListener)
        if(prefs.getBoolean("shift_active",false))startShift()
    }
    private fun screenWidth()=resources.displayMetrics.widthPixels
    private fun screenHeight()=resources.displayMetrics.heightPixels
    private fun clampPanel(tv:RadarPanelView,lp:WindowManager.LayoutParams){
        val h=(tv.referenceHeight*resources.displayMetrics.density*panelScale).toInt()
        lp.x=lp.x.coerceIn(0,(screenWidth()-lp.width).coerceAtLeast(0))
        lp.y=lp.y.coerceIn(0,(screenHeight()-h-dp(24)).coerceAtLeast(0))
    }
    private fun maxScale(tv:RadarPanelView)=minOf(1.8f,screenWidth()/(260f*resources.displayMetrics.density),(screenHeight()-dp(32))/(tv.referenceHeight*resources.displayMetrics.density)).coerceAtLeast(.4f)
    private fun saveGeometry(lp:WindowManager.LayoutParams){prefs.edit().putInt("radar_x",lp.x).putInt("radar_y",lp.y).putFloat("radar_scale",panelScale).apply()}
    private fun startShift(){
        if(running || !::windows.isInitialized)return
        running=true;routePipeline=OfflineRoutePipeline(this);lastScan=0;lastRadar=0;radar.clear()
        val tv=RadarPanelView(this)
        panelScale=prefs.getFloat("radar_scale",1f).coerceIn(.4f,maxScale(tv));tv.setPanelScale(panelScale)
        val lp=WindowManager.LayoutParams((dp(260)*panelScale).toInt(),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=prefs.getInt("radar_x",dp(8));y=prefs.getInt("radar_y",dp(162))}
        var initialX=0;var initialY=0;var touchX=0f;var touchY=0f;var moving=false;var pinched=false;var closeCandidate=false
        var startSpan=1f;var startScale=1f;var anchorX=0f;var anchorY=0f;var ratioX=0f;var ratioY=0f
        val slop=ViewConfiguration.get(this).scaledTouchSlop
        fun span(e:MotionEvent)=kotlin.math.hypot((e.getX(1)-e.getX(0)).toDouble(),(e.getY(1)-e.getY(0)).toDouble()).toFloat()
        tv.setOnTouchListener { _,e ->
            when(e.actionMasked){
                MotionEvent.ACTION_DOWN->{initialX=lp.x;initialY=lp.y;touchX=e.rawX;touchY=e.rawY;moving=false;pinched=false;closeCandidate=tv.closeHit(e.x,e.y);true}
                MotionEvent.ACTION_POINTER_DOWN->{
                    if(e.pointerCount==2){pinched=true;closeCandidate=false;startSpan=span(e).coerceAtLeast(1f);startScale=panelScale
                        anchorX=(e.getX(0)+e.getX(1))/2;anchorY=(e.getY(0)+e.getY(1))/2
                        ratioX=anchorX/lp.width.coerceAtLeast(1);ratioY=anchorY/tv.height.coerceAtLeast(1)
                        anchorX+=lp.x;anchorY+=lp.y
                    };true
                }
                MotionEvent.ACTION_MOVE->{
                    if(pinched && e.pointerCount==2){
                        panelScale=(startScale*span(e)/startSpan).coerceIn(minOf(.65f,maxScale(tv)),maxScale(tv));tv.setPanelScale(panelScale)
                        lp.width=(dp(260)*panelScale).toInt();lp.x=(anchorX-ratioX*lp.width).toInt();lp.y=(anchorY-ratioY*tv.referenceHeight*resources.displayMetrics.density*panelScale).toInt()
                        clampPanel(tv,lp);windows.updateViewLayout(tv,lp);movePopupNextToRadar()
                    } else if(!pinched){
                        if(abs(e.rawX-touchX)>slop||abs(e.rawY-touchY)>slop)moving=true
                        if(moving){lp.x=initialX+(e.rawX-touchX).toInt();lp.y=initialY+(e.rawY-touchY).toInt();clampPanel(tv,lp);windows.updateViewLayout(tv,lp);movePopupNextToRadar()}
                    };true
                }
                MotionEvent.ACTION_UP->{
                    saveGeometry(lp)
                    if(closeCandidate && !moving && !pinched && tv.closeHit(e.x,e.y))prefs.edit().putBoolean("shift_active",false).apply()
                    true
                }
                MotionEvent.ACTION_CANCEL->{saveGeometry(lp);true}
                else->true
            }
        }
        badge=tv;params=lp;clampPanel(tv,lp);windows.addView(tv,lp);render();ui.post(ticker)
    }
    private fun stopShift(){
        running=false;ui.removeCallbacks(ticker);closeOffer();radar.clear()
        if(::routePipeline.isInitialized)routePipeline.close()
        badge?.let{if(::windows.isInitialized)windows.removeView(it)};badge=null;params=null
    }
    /** Follows the radar on first appearance, without covering the Yandex accept button. */
    private fun movePopupNextToRadar() {
        val pp=popupParams ?: return
        if(popupDragged)return
        val rp=params ?: return
        val width=resources.displayMetrics.widthPixels
        val height=resources.displayMetrics.heightPixels
        pp.x=rp.x.coerceIn(0,(width-dp(240)).coerceAtLeast(0))
        val radarHeight=badge?.referenceHeight?.times(resources.displayMetrics.density*panelScale)?.toInt() ?: dp(55)
        val below=rp.y+radarHeight+dp(4)
        val above=rp.y-dp(108)
        pp.y=(if(below+dp(112)<=height)below else if(above>=dp(24))above else below).coerceIn(dp(24),(height-dp(112)).coerceAtLeast(dp(24)))
        popup?.let {windows.updateViewLayout(it,pp)}
    }
    private fun showFarePopup() {
        val v=popup
        if(v != null)return
        val p=OfferPopupView(this)
        val lp=WindowManager.LayoutParams(minOf(dp(240),screenWidth()),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {gravity=Gravity.TOP or Gravity.START}
        val parent=params
        lp.x=(parent?.x ?: dp(8))
        lp.y=(parent?.y ?: dp(48))+(badge?.referenceHeight?.times(resources.displayMetrics.density*panelScale)?.toInt() ?: dp(55))+dp(4)
        val safeW=(resources.displayMetrics.widthPixels-lp.width).coerceAtLeast(0)
        val safeH=(resources.displayMetrics.heightPixels-dp(112)).coerceAtLeast(dp(24))
        lp.x=lp.x.coerceIn(0,safeW);lp.y=lp.y.coerceIn(dp(24),safeH)
        popupDragged=false
        val slop=ViewConfiguration.get(this).scaledTouchSlop
        var touchX=0f;var touchY=0f;var initialX=0;var initialY=0;var moving=false
        p.setOnTouchListener { _, event ->
            when(event.actionMasked){
                MotionEvent.ACTION_DOWN->{
                    touchX=event.rawX;touchY=event.rawY
                    initialX=lp.x;initialY=lp.y;moving=false;true
                }
                MotionEvent.ACTION_MOVE->{
                    if(abs(event.rawX-touchX)>slop||abs(event.rawY-touchY)>slop)moving=true
                    if(moving){
                        popupDragged=true
                        lp.x=(initialX+(event.rawX-touchX).toInt()).coerceIn(0,safeW)
                        lp.y=(initialY+(event.rawY-touchY).toInt()).coerceIn(dp(24),safeH)
                        windows.updateViewLayout(p,lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP->{
                    if(!moving){
                        offerPopupState.dismiss()
                        hideFarePopup()
                        render()
                    };true
                }
                else->true
            }
        }
        popup=p;popupParams=lp
        windows.addView(p,lp)
    }
    private fun hideFarePopup() {
        popup?.let { p -> if(::windows.isInitialized)windows.removeView(p) }
        popup=null;popupParams=null;popupDragged=false
    }
    private fun closeOffer() {
        detected=OrderTextParser.Detected(false,null,null,false,null,null,null,null)
        routeKey=null;estimate=null;routeStatus="";nonOrderSnapshots=0
        offerPopupState.clear()
        hideFarePopup()
    }

    override fun onAccessibilityEvent(event:AccessibilityEvent?) {
        if(event==null || !running)return
        // Read only the specifically selected public app, not messages or other apps.
        if(event.packageName?.toString()!="ru.yandex.taximeter")return
        val now=System.currentTimeMillis()
        if(now-lastScan<450L)return
        lastScan=now
        val texts=mutableListOf<String>()
        fun walk(n:AccessibilityNodeInfo?,depth:Int){
            if(n==null||depth>22||texts.size>200)return
            n.text?.toString()?.takeIf{it.isNotBlank()}?.let {texts.add(it)}
            n.contentDescription?.toString()?.takeIf{it.isNotBlank()}?.let{texts.add(it)}
            for(i in 0 until n.childCount)walk(n.getChild(i),depth+1)
        }
        val root=rootInActiveWindow
        if(root?.packageName?.toString()!="ru.yandex.taximeter")return
        walk(root,0)
        if(texts.isEmpty()){
            if(event.eventType==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                closeOffer();render()
            }
            return
        }
        val visible=texts.distinct().joinToString("\n")
        val newer=OrderTextParser.parse(visible)
        if(newer.order) {
            nonOrderSnapshots=0
            offerPopupState.observe(true,OfferPopupState.identity(newer.pickup,newer.destination,newer.tariff))
            detected=newer
            // Trigger once per unique visible order; do not re-geocode on each accessibility event.
            val key="${newer.pickup}|${newer.destination}|${newer.tariff}|${newer.demand}|${newer.verifiedHighDemandDiscount}|${newer.tariff?.let{CommissionSettings.percent(prefs,it)}}|${CommissionSettings.loyalty(prefs)}|${CommissionSettings.park(prefs)}"
            if(key!=routeKey){
                routeKey=key;estimate=null
                val rate=TarifCatalog.forName(newer.tariff)
                if(newer.pickup.isNullOrBlank()||newer.destination.isNullOrBlank()||rate==null){
                    routeStatus="Адреса А/Б или тариф недоступны Android"
                } else {
                    routeStatus="Маршрут рассчитывается..."
                    val thisKey=key
                    val calcStartedAt=android.os.SystemClock.elapsedRealtime()
                    routePipeline.calculate(newer.pickup,newer.destination) { result ->
                        if (!running || routeKey!=thisKey)return@calculate
                        result.fold(onSuccess={r->
                            val y=CommissionSettings.percent(prefs,rate.title)
                            val p=CommissionSettings.park(prefs)
                            estimate=runCatching {
                                RouteFareEstimator.calculateWithCommission(rate,r,newer.demand?:Demand(DemandType.NONE),
                                    y,p,CommissionSettings.loyalty(prefs),newer.verifiedHighDemandDiscount)
                            }.getOrNull()
                            if (estimate != null) {
                                val demandLabel=when(newer.demand?.type){
                                    DemandType.FIXED_ADD -> "+${newer.demand!!.amount.toInt()} ₸"
                                    DemandType.MULTIPLIER -> "×${newer.demand!!.amount}"
                                    else -> "нет"
                                }
                                // Automatically preserve the BEFORE-ACTUAL prediction; never record passenger addresses.
                                TrialStore.append(this@RadarAccessibilityService,rate.title,estimate!!,demandLabel,
                                    android.os.SystemClock.elapsedRealtime()-calcStartedAt)
                            }
                            routeStatus=if(estimate!=null)"Офлайн BRouter • без живых пробок" else "Ошибка тарифной модели"
                        },onFailure={routeStatus="Нет маршрута: ${result.exceptionOrNull()?.message?.take(64)}"})
                        render()
                    }
                }
            }
        } else if (event.eventType==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            closeOffer()
        } else if (detected.order) {
            // Avoid flicker caused by a partial accessibility tree snapshot.
            // Confirm disappearance on two separate non-offer observations.
            nonOrderSnapshots++
            if (nonOrderSnapshots>=2) closeOffer()
        }
        val interval=prefs.getInt("interval",10)*1000L
        if(now-lastRadar>=interval){
            lastRadar=now
            // An observed label is only a label. Not all tariffs or exact GPS point!
            if(!newer.order && newer.tariff!=null && newer.demand!=null && prefs.getBoolean("tariff_${newer.tariff}",newer.tariff in TarifCatalog.defaultSelected)){
                val d=newer.demand
                val caption=if(d.type==DemandType.FIXED_ADD)"+${d.amount.toInt()} ₸" else "—"
                radar.put(RadarObservation(newer.tariff,caption,now,"видимый текст",false))
            }
        }
        render()
    }
    private fun render() {
        val current=badge ?: return
        val now=System.currentTimeMillis()
        val selected=TarifCatalog.radarOrder.filter {
            prefs.getBoolean("tariff_$it",it in TarifCatalog.defaultSelected)
        }
        val order=detected.order
        val rows=TarifCatalog.radarOrder.map { tariff ->
            val local=radar.current(tariff,false,now)
            val airport=radar.current(tariff,true,now)
            RadarPanelRow(TarifCatalog.shortName(tariff),local?.caption ?: "—",airport?.caption ?: "—",
                local!=null && local.source!="verified_gps",airport!=null && airport.source!="verified_airport")
        }
        current.showRadar(RadarPanelModel.visible(rows,selected.map{TarifCatalog.shortName(it)}.toSet()),prefs.getBoolean("airport",true))
        val lp=params
        if(lp!=null){
            val oldX=lp.x;val oldY=lp.y;val oldW=lp.width
            panelScale=panelScale.coerceAtMost(maxScale(current));current.setPanelScale(panelScale)
            lp.width=(dp(260)*panelScale).toInt();clampPanel(current,lp)
            if(oldX!=lp.x||oldY!=lp.y||oldW!=lp.width){windows.updateViewLayout(current,lp);saveGeometry(lp)}
        }
        if(order && offerPopupState.shouldShow()){
            showFarePopup()
            val demand=detected.demand?.let {
                when(it.type){
                    DemandType.FIXED_ADD -> "+${it.amount.toInt()} ₸"
                    DemandType.MULTIPLIER -> "×${it.amount}"
                    else -> "спрос —"
                }
            } ?: "спрос —"
            popup?.showQuote(detected.tariff?.let {TarifCatalog.shortName(it)} ?: "Заказ",
                demand,estimate,routeStatus,
                detected.tariff?.let {TarifCatalog.rateExpired(it)} ?: TarifCatalog.expiredToday(),
                CommissionSettings.park(prefs))
        } else hideFarePopup()
        movePopupNextToRadar()
    }
    override fun onInterrupt(){}
    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(settingsListener)
        stopShift()
        super.onDestroy()
    }
}
