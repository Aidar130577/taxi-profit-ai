package kz.taxiprofitai

import android.content.SharedPreferences

/** Local editable per-category settings. Never silently reuse the old global 19.2% field. */
object CommissionSettings {
    private fun key(tariff:String) = "commission_rate_" + tariff
    /** V12 migration: no Driver tariff or obsolete Driver preferences.
     * Preserve all manually set valid percentages for the six remaining tariffs.
     */
    fun migrateV12Defaults(prefs:SharedPreferences) {
        if (prefs.getInt("commission_catalog_schema",10)>=12) return
        val oldEconom=prefs.getString(key("Эконом"),null)
        prefs.edit().apply {
            if (oldEconom=="17.0" || oldEconom=="17") putString(key("Эконом"),"17.1")
            remove("tariff_Водитель")
            remove(key("Водитель"))
            putInt("commission_catalog_schema",12)
        }.apply()
    }
    fun percent(prefs:SharedPreferences,tariff:String):Double? {
        migrateV12Defaults(prefs)
        val raw=prefs.getString(key(tariff),null)
        val default=CommissionCatalog.forTariff(tariff).referencePct
        if(raw==null)return default
        if(raw.isBlank())return null
        return raw.replace(',','.').toDoubleOrNull()?.takeIf{it.isFinite() && it in 0.0..100.0}
    }
    fun wasEdited(prefs:SharedPreferences,tariff:String) = prefs.contains(key(tariff))
    fun save(editor:SharedPreferences.Editor,tariff:String,pct:Double?) {
        editor.putString(key(tariff),pct?.toString()?:"")
    }
    fun park(prefs:SharedPreferences) = prefs.getString("park","1")?.toDoubleOrNull()?.takeIf {it in 0.0..100.0}?:1.0
    fun loyalty(prefs:SharedPreferences):Double = when(prefs.getInt("loyalty_discount",0)){3->3.0;8->8.0;else->0.0}
}
