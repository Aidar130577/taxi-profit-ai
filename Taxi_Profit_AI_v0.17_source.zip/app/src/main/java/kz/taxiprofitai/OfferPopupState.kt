package kz.taxiprofitai

/** Controls only the separate fare popup, not the persistent radar overlay.
 * The offer identity deliberately ignores demand/commission/ETA changes so a
 * dismissed quote cannot reappear when Yandex refreshes the same card.
 */
class OfferPopupState {
    private var active = false
    private var identity: String? = null
    private var dismissed = false

    /** A partial card has null identity; it never unlocks a previously dismissed popup. */
    fun observe(isOffer: Boolean, stableIdentity: String? = null) {
        if (!isOffer) { clear(); return }
        if (!active) {
            active = true
            identity = stableIdentity
            dismissed = false
        } else if (stableIdentity != null) {
            if (identity == null) identity = stableIdentity
            else if (stableIdentity != identity) {
                identity = stableIdentity
                dismissed = false
            }
        }
    }

    fun dismiss() { if (active) dismissed = true }
    fun shouldShow(): Boolean = active && !dismissed
    fun isDismissed(): Boolean = active && dismissed
    fun clear() { active = false; identity = null; dismissed = false }

    companion object {
        fun identity(pickup: String?, destination: String?, tariff: String?): String? {
            if (pickup.isNullOrBlank() || destination.isNullOrBlank() || tariff.isNullOrBlank()) return null
            fun norm(s: String) = s.trim().lowercase().replace(Regex("\\s+"), " ")
            return "${norm(tariff)}|${norm(pickup)}|${norm(destination)}"
        }
    }
}
