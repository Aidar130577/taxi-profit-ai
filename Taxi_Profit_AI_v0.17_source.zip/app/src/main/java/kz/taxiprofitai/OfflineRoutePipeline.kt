package kz.taxiprofitai

import android.content.Context
import android.location.Geocoder
import android.os.Handler
import android.os.Looper
import java.util.Locale
import java.util.concurrent.Executors

/** Address -> coordinates -> BRouter, without storing passenger addresses or contacting proprietary APIs.
 * The OS geocoder may require network / return no results. This is surfaced, not hidden.
 */
class OfflineRoutePipeline(context: Context) {
    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val geocodeWorker = Executors.newSingleThreadExecutor()
    private val brouter = BRouterConnector(appContext)
    private val pointCache = object: LinkedHashMap<String,BRouterConnector.Point>(32,0.75f,true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String,BRouterConnector.Point>?): Boolean = size > 32
    }
    @Volatile private var closed = false
    // Short-lived in-memory cache only; never persist passenger addresses/coordinates.
    private val routeCache = object: LinkedHashMap<String,Pair<Long,OfflineRoute>>(20,0.75f,true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String,Pair<Long,OfflineRoute>>?): Boolean = size > 20
    }
    private val routeTtlMs = 5 * 60 * 1000L

    fun calculate(a: String, b: String, callback: (Result<OfflineRoute>) -> Unit) {
        if (closed) return
        val key = a.trim().lowercase(Locale.ROOT) + "|" + b.trim().lowercase(Locale.ROOT)
        val existing = synchronized(routeCache) { routeCache[key] }
        if (existing!=null && System.currentTimeMillis()-existing.first in 0..routeTtlMs) {
            ui.post { if(!closed) callback(Result.success(existing.second)) }
            return
        }
        geocodeWorker.execute {
            val pair = runCatching { resolve(a) to resolve(b) }
            ui.post {
                if (closed) return@post
                pair.fold(onSuccess = { (p1,p2) -> brouter.route(p1,p2) {r ->
                    r.onSuccess {route -> synchronized(routeCache) {routeCache[key]=System.currentTimeMillis() to route} }
                    callback(r)
                } }, onFailure={callback(Result.failure(it))})
            }
        }
    }
    private fun resolve(raw: String): BRouterConnector.Point {
        val norm=raw.trim().lowercase(Locale.ROOT)
        synchronized(pointCache) { pointCache[norm]?.let { return it } }
        // Explicit coordinates are helpful for a completely offline routing test, without any geocoder.
        val match=Regex("^\\s*(4[23]\\.\\d{3,}),\\s*(7[567]\\.\\d{3,})\\s*$").find(norm)
        val found=if(match!=null) BRouterConnector.Point(match.groupValues[1].toDouble(),match.groupValues[2].toDouble())
        else {
            @Suppress("DEPRECATION")
            val list=Geocoder(appContext,Locale("ru","KZ")).getFromLocationName("$raw, Алматы, Казахстан",5)
            val valid=list?.firstOrNull { it.latitude in 42.5..44.5 && it.longitude in 75.0..79.0 }
                ?: error("Не удалось найти адрес: $raw. Проверь адрес или введи координаты.")
            BRouterConnector.Point(valid.latitude,valid.longitude)
        }
        synchronized(pointCache) { pointCache[norm]=found }
        return found
    }
    fun close() { closed=true; brouter.close();geocodeWorker.shutdownNow();synchronized(pointCache){pointCache.clear()};synchronized(routeCache){routeCache.clear()} }
}
