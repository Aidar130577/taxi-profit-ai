package kz.taxiprofitai

/** Pure UI pagination logic: visible rows without pagination. */
data class RadarPanelRow(
    val tariff: String,
    val here: String,
    val airport: String,
    val hereApproximate: Boolean = false,
    val airportApproximate: Boolean = false
)
object RadarPanelModel {
    fun visible(items:List<RadarPanelRow>,enabled:Set<String>)=items.filter{it.tariff in enabled}
    fun height(count:Int)=55f+25f*count.coerceAtLeast(1)
    fun display(text: String, approximate: Boolean): String =
        when { text.isBlank() || text == "—" || !text.endsWith("₸") -> "—"; approximate -> "~$text"; else -> text }
}
