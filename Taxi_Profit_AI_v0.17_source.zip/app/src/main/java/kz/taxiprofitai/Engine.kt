package kz.taxiprofitai

import kotlin.math.max
import kotlin.math.roundToInt
import java.time.LocalDate

enum class DemandType { NONE, FIXED_ADD, MULTIPLIER, MINIMUM_BONUS }
data class Demand(val type: DemandType, val amount: Double = 0.0, val verified: Boolean = false)
data class TariffRate(val title: String, val start: Double, val includedKm: Double, val includedMinutes: Double, val perKm: Double, val perMinute: Double)
data class RouteEstimate(val km: Double, val minutes: Double)
data class FareQuote(val low: Double, val high: Double, val mean: Double, val driverEstimate: Double, val source: String)

/** Published fares are upper limits and can vary by park, border and airport. NO network call is made. */
object FareEngine {
    fun base(rate: TariffRate, r: RouteEstimate): Double {
        require(r.km.isFinite() && r.minutes.isFinite() && r.km >= 0.0 && r.minutes >= 0.0)
        return rate.start + max(0.0, r.km - rate.includedKm) * rate.perKm + max(0.0, r.minutes - rate.includedMinutes) * rate.perMinute
    }

    fun applyDemand(base: Double, d: Demand): Double {
        require(base.isFinite() && base >= 0.0)
        require(d.amount.isFinite() && d.amount >= 0.0)
        return when (d.type) {
        DemandType.NONE -> base
        DemandType.FIXED_ADD -> if (d.verified) base + d.amount else base
        DemandType.MULTIPLIER -> if (d.verified && d.amount >= 1.0) base * d.amount else base
        // The exact application of minimum bonuses is unknown; don't add it to passenger fare.
        DemandType.MINIMUM_BONUS -> base
        }
    }

    /** Confirmed optional charges only. Do not extrapolate these from a pickup ETA. */
    fun detailed(rate: TariffRate, route: RouteEstimate, demand: Demand,
                 extras: ConfirmedExtras = ConfirmedExtras()): FareBreakdown {
        val riding = base(rate, route)
        val withDemand = applyDemand(riding, demand)
        val waiting = if (extras.paidWaitingConfirmed) extras.paidWaitingMinutes * extras.waitRate else 0.0
        val pickup = if (extras.paidPickupConfirmed) extras.pickupCharge else 0.0
        val airport = if (extras.airportChargeConfirmed) extras.airportCharge else 0.0
        require(listOf(waiting,pickup,airport).all { it.isFinite() && it >= 0.0 })
        return FareBreakdown(riding,withDemand-riding,waiting,pickup,airport,
            withDemand+waiting+pickup+airport)
    }

    fun quote(rate: TariffRate, route1: RouteEstimate, route2: RouteEstimate, demand: Demand,
              yandexPct: Double, parkPct: Double, source: String): FareQuote {
        require(route1.km >= 0 && route2.km >= 0 && route1.minutes >= 0 && route2.minutes >= 0)
        require(yandexPct in 0.0..100.0 && parkPct in 0.0..100.0 && yandexPct + parkPct <= 100.0)
        val a = applyDemand(base(rate, route1), demand)
        val b = applyDemand(base(rate, route2), demand)
        val mean = (a + b) / 2.0 // No intermediate rounding.
        return FareQuote(minOf(a,b), maxOf(a,b), mean, mean * (1.0 - (yandexPct + parkPct) / 100.0), source)
    }

    fun kzt(x: Double): String = "${x.roundToInt()} ₸"
}

/** Extra fees are included ONLY when actually confirmed. They are zero for a new order by default. */
data class ConfirmedExtras(
    val paidWaitingMinutes: Double = 0.0, val waitRate: Double = 0.0,
    val paidWaitingConfirmed: Boolean = false,
    val pickupCharge: Double = 0.0, val paidPickupConfirmed: Boolean = false,
    val airportCharge: Double = 0.0, val airportChargeConfirmed: Boolean = false
)
data class FareBreakdown(val ride: Double, val demand: Double, val waiting: Double,
                         val pickup: Double, val airport: Double, val gross: Double)

object TarifCatalog {
    const val lastVerified = "2026-11-24"
    const val ratesValidThrough = "2026-11-24" // Published rates, not a live price feed.
    fun expiredToday(today: LocalDate = LocalDate.now()): Boolean = today.isAfter(LocalDate.parse(ratesValidThrough))
    // Published maximum ALMATY tariff rates, verified 24.11.2026. NOT exact Yandex passenger pricing.
    // After validity date, UI must show "историческая ставка". No silent updates.
    // ALMATY: published maximum rates observed 2026-11-24, not a live tariff feed.
    val rates = listOf(
        TariffRate("Эконом",400.0,1.0,3.0,58.0,27.0),
        TariffRate("Комфорт",490.0,1.0,3.0,72.0,31.0),
        TariffRate("Комфорт+",595.0,1.0,3.0,83.0,39.0),
        TariffRate("Электро",655.0,1.0,3.0,91.0,42.0),
        TariffRate("Business",840.0,1.0,3.0,123.0,54.0),
        TariffRate("Premier",1170.0,1.0,3.0,160.0,75.0)
    )
    // Stable identifiers for settings and order matching remain full tariff names.
    val shortLabels = mapOf(
        "Эконом" to "EK", "Комфорт" to "K", "Комфорт+" to "K+",
        "Электро" to "EV", "Business" to "BS", "Premier" to "PR"
    )
    val radarOrder = listOf("Эконом","Комфорт","Комфорт+","Электро","Business","Premier")
    val defaultSelected = setOf("Эконом","Комфорт","Комфорт+","Электро","Business","Premier")
    fun shortName(name:String):String = shortLabels[name] ?: name
    @Suppress("UNUSED_PARAMETER")
    fun rateExpired(name:String, today:LocalDate=LocalDate.now()):Boolean = expiredToday(today)
    val titles = rates.map{it.title}
    fun forName(name: String?): TariffRate? = rates.firstOrNull{it.title.equals(name,ignoreCase=true)}
    val businessReference = forName("Business")!!
}

/** Native text available via Android Accessibility tree. No image/OCR or private Yandex API. */
object OrderTextParser {
    data class Detected(val order: Boolean, val tariff: String?, val demand: Demand?, val airport: Boolean,
                        val pickup: String?, val destination: String?, val pickupKm: Double?, val pickupMin: Int?,
                        val verifiedHighDemandDiscount: Boolean = false)
    private val fixed = Regex("\\+\\s*(\\d[\\d\\s]*)\\s*[₸Т](?!\\w)", RegexOption.IGNORE_CASE)
    private val mult = Regex("[×xх]\\s*(\\d+[,.]\\d+)", RegexOption.IGNORE_CASE)
    private val pickup = Regex("(\\d+[,.]\\d+)\\s*км\\s*[·•\\-]\\s*(\\d+)\\s*мин", RegexOption.IGNORE_CASE)
    private val excludedOrder = Regex("(?iu)(?<![\\p{L}])(доставка|курьер|грузовой|яндекс\\s+еда|межгород|вместе)(?![\\p{L}])")
    fun parse(text: String): Detected {
        val t = text.replace('\u00a0',' ')
        val isOrder = t.contains("Принять",true) &&
            (Regex("Пропустить",RegexOption.IGNORE_CASE).containsMatchIn(t) || t.contains("подача",true))
        val tariff = TarifCatalog.titles.sortedByDescending { it.length }.firstOrNull { name ->
            Regex("(?<![\\p{L}])"+Regex.escape(name)+"(?![\\p{L}])", RegexOption.IGNORE_CASE).containsMatchIn(t)
        }
        // Priority +1 (radar icon) is NOT an increase in fare.
        val d = fixed.find(t)?.groupValues?.get(1)?.replace(" ","")?.toDoubleOrNull()?.let { Demand(DemandType.FIXED_ADD,it,true) }
            ?: mult.find(t)?.groupValues?.get(1)?.replace(",",".")?.toDoubleOrNull()?.let { Demand(DemandType.MULTIPLIER,it,true) }
        val pm = pickup.find(t)
        val addresses = t.lines().map { it.trim() }.filter { it.isNotBlank() }
        fun extract(marker: String): String? {
            // Yandex accessibility trees may expose the marker as a separate node.
            val i = addresses.indexOfFirst { it == marker || it.startsWith("$marker ") || it.startsWith("$marker:") }
            if (i < 0) return null
            val s = addresses[i]
            if (s.length > 2) return s.drop(1).trim(' ', ':')
            return addresses.getOrNull(i+1)?.takeIf { it.length > 5 && it != "Пропустить" && it != "Принять" }
        }
        val a = extract("А") ?: extract("A")
        val b = extract("Б") ?: extract("B")
        return Detected(isOrder,if(excludedOrder.containsMatchIn(t)) null else tariff,d,t.contains("аэропорт",true), a,b,
            pm?.groupValues?.get(1)?.replace(",",".")?.toDoubleOrNull(), pm?.groupValues?.get(2)?.toIntOrNull(),
            t.contains("Очень высокий спрос",true) && t.contains("Комиссия снижена",true))
    }
}

/** A radar observation is never fabricated: it must come from observed data. */
data class RadarObservation(val tariff: String, val caption: String, val timestampMs: Long, val source: String, val airport: Boolean)
class RadarMemory {
    private val obs = mutableMapOf<String,RadarObservation>()
    fun clear() { obs.clear() }
    fun put(o: RadarObservation) { obs["${o.tariff}|${o.airport}"] = o }
    fun current(tariff: String, airport: Boolean, now: Long, maxAgeMs: Long = 30_000): RadarObservation? {
        val o = obs["$tariff|$airport"] ?: return null
        return if (now - o.timestampMs <= maxAgeMs && now >= o.timestampMs) o else null
    }
}

/** One real calculated route: do not average two fabricated routes. */
data class LiveFareEstimate(val gross: Double, val net: Double?, val km: Double,
                            val minutes: Double, val source: String,
                            val commission: CommissionBreakdown? = null)
object RouteFareEstimator {
    // Existing API retained for local historical benchmarks; new call sites use commission catalog.
    fun calculate(rate:TariffRate, route:OfflineRoute, demand:Demand, yandexPct:Double, parkPct:Double):LiveFareEstimate =
        calculateWithCommission(rate,route,demand,yandexPct,parkPct)

    fun calculateWithCommission(rate:TariffRate, route:OfflineRoute, demand:Demand,
                                yandexPct:Double?, parkPct:Double,
                                loyaltyDiscountPoints:Double=0.0,
                                verifiedHighDemandBanner:Boolean=false):LiveFareEstimate {
        require(demand.type != DemandType.MULTIPLIER || (demand.verified && demand.amount>=1.0))
        val parts=FareEngine.detailed(rate,RouteEstimate(route.km,route.minutes),demand)
        val commission=CommissionCatalog.calculate(parts.gross,parts.ride,yandexPct,parkPct,
            loyaltyDiscountPoints,verifiedHighDemandBanner)
        return LiveFareEstimate(parts.gross,commission.net,route.km,route.minutes,route.source,commission)
    }
}
