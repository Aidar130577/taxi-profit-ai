package kz.taxiprofitai

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import btools.routingapp.IBRouterService
import java.util.ArrayDeque
import java.util.concurrent.Executors

/** Uses the documented public Android bound service of the separately installed BRouter app.
 * No HTTP calls, subscriptions or Yandex/KazKef private interfaces.
 * Must be configured in BRouter with downloaded .rd5 map segments and motorcar_fast profile.
 */
class BRouterConnector(private val context: Context) {
    data class Point(val lat: Double, val lon: Double) {
        init { require(lat in -90.0..90.0 && lon in -180.0..180.0) }
    }
    private data class Request(val a: Point, val b: Point, val callback: (Result<OfflineRoute>) -> Unit)
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val queue = ArrayDeque<Request>()
    private var router: IBRouterService? = null
    private var bound = false
    private var closed = false
    private val connection = object: ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            router = IBRouterService.Stub.asInterface(binder)
            drain()
        }
        override fun onServiceDisconnected(name: ComponentName?) { router = null }
        override fun onBindingDied(name: ComponentName?) { router = null; failPending("Служба BRouter отключилась") }
        override fun onNullBinding(name: ComponentName?) { failPending("BRouter не предоставил службу") }
    }

    /** Call from Android main thread; callback is delivered on the same thread. */
    fun route(a: Point, b: Point, callback: (Result<OfflineRoute>) -> Unit) {
        if (closed) { callback(Result.failure(IllegalStateException("Маршрутизатор закрыт"))); return }
        queue.addLast(Request(a,b,callback))
        if (router != null) { drain();return }
        if (!bound) {
            val i = Intent().setClassName("btools.routingapp", "btools.routingapp.BRouterService")
            try {
                bound = context.bindService(i, connection, Context.BIND_AUTO_CREATE)
                if (!bound) failPending("BRouter не установлен или его сервис недоступен")
            } catch (e: Exception) {
                bound = false
                failPending("Не удалось подключить BRouter: ${e.message}")
            }
        }
    }
    private fun drain() {
        val service = router ?: return
        while (queue.isNotEmpty()) {
            val q = queue.removeFirst()
            worker.execute {
                val result = runCatching {
                    val p = Bundle().apply {
                        putString("lonlats", "${q.a.lon},${q.a.lat}|${q.b.lon},${q.b.lat}")
                        putString("v", "motorcar")
                        putString("fast", "1")
                        putString("trackFormat", "json")
                        putString("maxRunningTime", "12")
                    }
                    val raw = service.getTrackFromParams(p) ?: error("BRouter вернул пустой маршрут")
                    BRouterRouteResult.parse(raw)
                }
                ui.post { if (!closed) q.callback(result) }
            }
        }
    }
    private fun failPending(message: String) {
        while (queue.isNotEmpty()) queue.removeFirst().callback(Result.failure(IllegalStateException(message)))
    }
    fun close() {
        closed=true
        failPending("Маршрутизатор закрыт")
        if (bound) runCatching { context.unbindService(connection) }
        bound=false; router=null
        worker.shutdownNow()
    }
}
