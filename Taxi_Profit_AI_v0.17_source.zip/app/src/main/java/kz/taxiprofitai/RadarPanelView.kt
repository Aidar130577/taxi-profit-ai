package kz.taxiprofitai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** The approved compact radar. All drawing and hit coordinates use the same reference scale. */
class RadarPanelView(context: Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var rows:List<RadarPanelRow> = emptyList()
    private var airport=true
    private var scale=1f
    private val density=resources.displayMetrics.density
    private val unit get()=density*scale
    val referenceWidth=260f
    val referenceHeight get()=RadarPanelModel.height(rows.size)
    private val white=Color.WHITE
    private val backgroundColor=Color.rgb(22,32,39)
    private val yellow=Color.rgb(255,225,0)
    private val purple=Color.rgb(184,116,255)
    init { isClickable=true; importantForAccessibility=IMPORTANT_FOR_ACCESSIBILITY_YES }
    fun setPanelScale(value:Float){ if(scale!=value){scale=value;requestLayout();invalidate()} }
    fun closeHit(x:Float,y:Float)=x/unit>=232f && y/unit<=28f
    override fun onMeasure(w:Int,h:Int){setMeasuredDimension(resolveSize((referenceWidth*unit).toInt(),w),resolveSize((referenceHeight*unit).toInt(),h))}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int=white,bold:Boolean=false,align:Paint.Align=Paint.Align.LEFT,maxWidth:Float=1000f){
        paint.style=Paint.Style.FILL;paint.color=color;paint.textSize=size;paint.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;paint.textAlign=align;paint.textScaleX=1f
        val width=paint.measureText(s);if(width>maxWidth)paint.textScaleX=maxWidth/width
        c.drawText(s,x,y,paint);paint.textScaleX=1f
    }
    private fun line(c:Canvas,x1:Float,y1:Float,x2:Float,y2:Float,color:Int=white,thickness:Float=.8f){paint.color=color;paint.style=Paint.Style.STROKE;paint.strokeWidth=thickness;c.drawLine(x1,y1,x2,y2,paint);paint.style=Paint.Style.FILL}
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas);canvas.save();canvas.scale(unit,unit)
        val h=referenceHeight
        paint.style=Paint.Style.FILL;paint.color=backgroundColor;canvas.drawRoundRect(RectF(1f,1f,259f,h-1),8f,8f,paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=1.5f;paint.color=Color.rgb(73,89,106);canvas.drawRoundRect(RectF(1f,1f,259f,h-1),8f,8f,paint);paint.style=Paint.Style.FILL
        text(canvas,"TAXI PROFIT AI · РАДАР",119f,20f,14f,Color.rgb(133,230,166),true,Paint.Align.CENTER,221f)
        line(canvas,240f,9f,251f,20f,white,2f);line(canvas,251f,9f,240f,20f,white,2f)
        line(canvas,5f,28f,255f,28f)
        text(canvas,"Тариф",10f,44f,13f)
        val hereX=if(airport)110f else 180f
        val markerX=if(airport)80f else 150f
        val pin=Path().apply{moveTo(markerX,34f);cubicTo(markerX-7,34f,markerX-7,40f,markerX,45f);cubicTo(markerX+7,40f,markerX+7,34f,markerX,34f);close()}
        paint.color=white;canvas.drawPath(pin,paint);paint.color=backgroundColor;canvas.drawCircle(markerX,37.8f,1.8f,paint)
        text(canvas,"Я здесь",hereX+6,44f,13f,align=Paint.Align.CENTER)
        if(airport){
            val plane=Path().apply{moveTo(174f,33f);lineTo(176f,33f);lineTo(176f,37f);lineTo(181f,41f);lineTo(181f,43f);lineTo(176f,40f);lineTo(176f,44f);lineTo(178f,46f);lineTo(172f,46f);lineTo(174f,44f);lineTo(174f,40f);lineTo(169f,43f);lineTo(169f,41f);lineTo(174f,37f);close()}
            paint.color=white;canvas.drawPath(plane,paint)
            text(canvas,"Аэропорт",218f,44f,13f,align=Paint.Align.CENTER,maxWidth=72f)
            line(canvas,161f,29f,161f,h-5)
        }
        line(canvas,5f,51f,255f,51f)
        if(rows.isEmpty())text(canvas,"Выберите тарифы в настройках",130f,70f,11f,align=Paint.Align.CENTER)
        rows.forEachIndexed {i,r ->
            val y=70f+i*25f
            text(canvas,r.tariff,12f,y,16f,bold=true)
            text(canvas,RadarPanelModel.display(r.here,r.hereApproximate),hereX,y,16f,yellow,true,Paint.Align.CENTER,if(airport)94f else 140f)
            if(airport)text(canvas,RadarPanelModel.display(r.airport,r.airportApproximate),210f,y,16f,purple,true,Paint.Align.CENTER,88f)
            if(i<rows.lastIndex)line(canvas,5f,y+6,255f,y+6,Color.rgb(99,113,123),.6f)
        }
        canvas.restore()
    }
    fun showRadar(newRows:List<RadarPanelRow>,showAirport:Boolean){
        if(rows==newRows && airport==showAirport)return
        val sizeChanged=rows.size!=newRows.size
        rows=newRows;airport=showAirport
        contentDescription="Радар Taxi Profit AI. "+rows.joinToString("; "){"${it.tariff}, здесь ${it.here}"+if(airport) ", аэропорт ${it.airport}" else ""}+". Тильда — показание без подтверждённой геопозиции."
        if(sizeChanged)requestLayout();invalidate()
    }
}
