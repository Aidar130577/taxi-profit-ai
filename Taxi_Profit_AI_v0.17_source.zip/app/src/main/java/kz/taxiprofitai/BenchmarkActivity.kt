package kz.taxiprofitai

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Auditable benchmark and phone-only experiment log; historical test rows are read-only. */
class BenchmarkActivity: Activity() {
    private fun newLabel(text: String, size: Float = 15f, color: Int = Color.rgb(26,39,46)): TextView =
        TextView(this).apply {this.text=text;textSize=size;setTextColor(color);setPadding(0,11,0,5)}
    override fun onCreate(savedInstanceState: Bundle?) {super.onCreate(savedInstanceState);refresh()}
    private fun refresh() {
        val wrap=ScrollView(this)
        val col=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(24,28,24,36)
            setBackgroundColor(Color.rgb(248,250,250))
        }
        col.addView(newLabel("Taxi Profit AI · Проверка точности",21f))
        col.addView(newLabel("Здесь прогнозы, зафиксированные ДО цены Яндекса. Никакой подгонки после факта.",14f,Color.DKGRAY))
        val confirmed=BenchmarkLedger.stats()
        val all=BenchmarkLedger.stats(false)
        col.addView(newLabel("Подтверждено: ${confirmed.count} поездок из 9",18f))
        col.addView(newLabel("Средняя абсолютная ошибка: %.1f%% · %.0f ₸".format(Locale.US,
            confirmed.meanAbsolutePercentError,confirmed.meanAbsoluteErrorKzt),16f))
        col.addView(newLabel("С учётом одной неподтверждённой цены на экране: %.1f%%".format(Locale.US,all.meanAbsolutePercentError),13f,Color.DKGRAY))
        val sorted=BenchmarkLedger.trips.sortedBy { it.number }
        sorted.forEach {r->
            val emoji=if(r.absolutePercentError<5) "✓" else if(r.absolutePercentError<10) "○" else "!"
            val approx=if(r.state==ActualState.SCREEN_ONLY) " · цена на экране" else ""
            col.addView(newLabel("$emoji №${r.number} ${r.tariff}: ${FareEngine.kzt(r.baselineBeforeActual)} → ${FareEngine.kzt(r.actualGross)}$approx",15f))
            col.addView(newLabel("Ошибка %+.1f%% · %s".format(Locale.US, r.signedError/r.actualGross*100,
                FareEngine.kzt(abs(r.signedError))),12f,Color.DKGRAY))
            col.addView(newLabel(r.itinerary,12f,Color.DKGRAY))
        }
        col.addView(newLabel("Почему не применяем среднее 3 284 ₸ как доказанную модель",17f))
        col.addView(newLabel("Его рассчитали после того, как узнали фактические 3 210 ₸. Хорошее совпадение не доказывает работу заранее. Наш основной метод — один реальный маршрут BRouter + тариф + подтверждённая надбавка. Без полного начисления подачи по умолчанию.",14f,Color.DKGRAY))
        col.addView(newLabel("Новые испытания на твоём телефоне",19f))
        col.addView(newLabel("Приложение записывает только тариф, прогноз, километры, минуты и время. Адреса и данные пассажиров не сохраняются. После поездки можешь внести фактическую цену грязными.",14f,Color.DKGRAY))
        val items=TrialStore.read(this)
        if(items.isEmpty()) col.addView(newLabel("Пока нет автоматических прогнозов от BRouter.",14f,Color.DKGRAY))
        val dateFmt=SimpleDateFormat("dd.MM HH:mm",Locale("ru","KZ"))
        items.take(20).forEach {item ->
            val stamp=dateFmt.format(Date(item.createdAtMs))
            col.addView(newLabel("$stamp · ${item.tariff} · прогноз ${FareEngine.kzt(item.forecastGross)}",15f))
            val timing=item.latencyMs?.let {" · маршрут ${it} мс"} ?: ""
            col.addView(newLabel("%.1f км / %.1f мин · спрос ${item.demandLabel}$timing".format(Locale.US,item.km,item.minutes),12f,Color.DKGRAY))
            if(item.actualGross==null){
                val row=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
                val amount=EditText(this).apply {
                    hint="Факт, ₸";inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                }
                row.addView(amount,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
                row.addView(Button(this).apply {text="Записать";setOnClickListener {
                    val value=amount.text.toString().replace(',','.').toDoubleOrNull()
                    if(value==null || !TrialStore.setActual(this@BenchmarkActivity,item.id,value)) {
                        Toast.makeText(this@BenchmarkActivity,"Введите верную стоимость",Toast.LENGTH_SHORT).show()
                    } else refresh()
                }})
                col.addView(row)
            } else {
                val err=(item.forecastGross-item.actualGross)/item.actualGross*100
                col.addView(newLabel("Факт ${FareEngine.kzt(item.actualGross)} · ошибка %+.1f%%".format(Locale.US,err),13f))
            }
        }
        col.addView(newLabel("Важно: BRouter не знает живые пробки; это экспериментальная оценка и не стоимость, обещанная Яндексом.",13f,Color.DKGRAY))
        wrap.addView(col)
        setContentView(wrap)
    }
}
