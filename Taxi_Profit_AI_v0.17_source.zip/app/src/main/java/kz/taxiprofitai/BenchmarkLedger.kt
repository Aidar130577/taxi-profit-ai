package kz.taxiprofitai

import kotlin.math.abs

/**
 * Fixed, historical backtest ledger. Never use an observed result to modify a PRE-RESULT estimate.
 * Trip 08 is provisional: the shown price was not independently confirmed after finishing.
 * All gross values in KZT. Variants preserve exploratory estimates instead of cherry-picking.
 */
enum class ActualState { CONFIRMED, SCREEN_ONLY }

data class BenchmarkVariant(
    val label: String, val forecast: Double, val beforeActual: Boolean = true,
    val note: String = ""
)
data class BenchmarkTrip(
    val number: Int, val tariff: String, val itinerary: String,
    val baselineBeforeActual: Double, val actualGross: Double,
    val state: ActualState, val evidence: String,
    val variants: List<BenchmarkVariant> = emptyList()
) {
    val signedError: Double get() = baselineBeforeActual - actualGross
    val absolutePercentError: Double get() = abs(signedError) * 100.0 / actualGross
}
data class BenchmarkStats(
    val count: Int, val meanAbsoluteErrorKzt: Double,
    val meanAbsolutePercentError: Double
)

object BenchmarkLedger {
    val trips = listOf(
        BenchmarkTrip(1,"Комфорт+","Кунаева 119 → Бесагаш, Даркенбаева 14",3900.0,2630.0,
            ActualState.CONFIRMED,"Две точки известны, но 16,5 км / 27 мин были предположением"),
        BenchmarkTrip(2,"Business","Думан-2, 57 → Абылай хана 1",2450.0,2250.0,
            ActualState.CONFIRMED,"Маршрут/время предполагались; удержания известны"),
        BenchmarkTrip(3,"Business","Назарбаева 28А/14 → аэропорт, внутренние",2950.0,3210.0,
            ActualState.CONFIRMED,"Первый прогноз — 2950; перед фактом географический — 3650",
            variants=listOf(
                BenchmarkVariant("Расширенный до факта",3650.0),
                BenchmarkVariant("Среднее 2934 и 3634,50 ПОСЛЕ факта",3284.25,false,"Не годится для проверки прогнозирования"))),
        BenchmarkTrip(4,"Комфорт+","Аэропорт, международный → Солодовникова 21А",3182.0,3410.0,
            ActualState.CONFIRMED,"Двойная оценка до факта; аэропортовая надбавка не подтверждена",
            variants=listOf(
                BenchmarkVariant("Расширенный до факта, с гипотетической доплатой",3495.0),
                BenchmarkVariant("Подгонка по навигатору ПОСЛЕ факта",3329.0,false,"19 км / 28 мин были оставшимся путём"))),
        BenchmarkTrip(5,"Business","Айманова 208А → Тимирязева 42/10",1508.0,1580.0,
            ActualState.CONFIRMED,"Итог включал 3 мин ожидания, которых не знали при прогнозе",
            variants=listOf(BenchmarkVariant("С полной гипотетической оплатой подачи",1793.0))),
        BenchmarkTrip(6,"Business","SmArt.Point → Абая 160к1, маршрут через Сатпаева",1805.70,1550.0,
            ActualState.CONFIRMED,"В предположениях завышены километры/минуты",
            variants=listOf(BenchmarkVariant("С полной гипотетической оплатой подачи",2243.10))),
        BenchmarkTrip(7,"Комфорт+","Абая 164/8 → Розыбакиева 115",1190.0,930.0,
            ActualState.CONFIRMED,"3,5 км / 9 мин не были измерены"),
        BenchmarkTrip(8,"Комфорт+","Жандосова 2Б → Ади Шарипова 72",1136.70,970.0,
            ActualState.SCREEN_ONLY,"970 ₸ показано до завершения, финальная выписка не предоставлена"),
        BenchmarkTrip(9,"Business","Толе би 157/12 → аэропорт, международный",4126.50,4090.0,
            ActualState.CONFIRMED,"18,5 км / 24 мин предполагались; близкое совпадение ещё не валидация GPS"),
    )
    fun stats(confirmedOnly: Boolean = true): BenchmarkStats {
        val rows = if (confirmedOnly) trips.filter { it.state == ActualState.CONFIRMED } else trips
        require(rows.isNotEmpty())
        return BenchmarkStats(
            rows.size,
            rows.map { abs(it.signedError) }.average(),
            rows.map { it.absolutePercentError }.average()
        )
    }
    fun bestConfirmed(limit: Int = 3) = trips
        .filter { it.state == ActualState.CONFIRMED }
        .sortedBy { it.absolutePercentError }
        .take(limit)
}
