package kz.taxiprofitai

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

/**
 * Minimal 2D city map, not a copy of any driver app or KazKef.
 * There is no building/POI/hotel/landmark source-layer in either packaged style.
 * The map DOES NOT produce coefficients, routes, traffic or taxi fare by itself.
 */
class SimpleMapActivity : Activity() {
    private lateinit var mapView: MapView
    private val prefs by lazy { getSharedPreferences("taxi_profit_settings", MODE_PRIVATE) }
    private var isDark = true

    private fun panel(color: Int, corner: Float = 24f) = GradientDrawable().apply {
        setColor(color); cornerRadius = corner
    }
    private fun loadStyle() {
        val filename = if (isDark) "taxi_simple_dark.json" else "taxi_simple_light.json"
        val text = assets.open(filename).bufferedReader(Charsets.UTF_8).use { it.readText() }
        mapView.getMapAsync { map ->
            // Projection remains flat. Users can pan/zoom but not tilt into a 3D perspective.
            map.cameraPosition = CameraPosition.Builder()
                .target(LatLng(43.2389, 76.8897)).zoom(11.5).tilt(0.0).build()
            map.uiSettings.isTiltGesturesEnabled = false
            map.uiSettings.isRotateGesturesEnabled = false
            map.setStyle(Style.Builder().fromJson(text))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        isDark = prefs.getBoolean("map_dark", true)

        val root = FrameLayout(this)
        mapView = MapView(this)
        root.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        mapView.onCreate(savedInstanceState)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = panel(Color.rgb(23, 31, 34))
        }
        header.addView(TextView(this).apply {
            text = "TAXI PROFIT AI · КАРТА"
            setTextColor(Color.WHITE); textSize = 17f
        })
        header.addView(TextView(this).apply {
            text = "Только дороги и улицы · без 3D и достопримечательностей"
            setTextColor(Color.rgb(177, 195, 201)); textSize = 12f
        })
        val toggle = Button(this).apply {
            text = if (isDark) "Светлая карта" else "Тёмная карта"
            setOnClickListener {
                isDark = !isDark
                prefs.edit().putBoolean("map_dark", isDark).apply()
                text = if (isDark) "Светлая карта" else "Тёмная карта"
                loadStyle()
            }
        }
        header.addView(toggle)
        val hParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.TOP)
        hParams.setMargins(16,24,16,0)
        root.addView(header,hParams)

        val footer = TextView(this).apply {
            text = "Спрос по тарифам: — (источник не подключён)\n✈ Аэропорт Алматы: — (источник не подключён)"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(22,16,22,16)
            background = panel(Color.rgb(23,31,34))
        }
        val fParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        // Reserve the bottom area for legally required MapLibre map data attribution.
        fParams.setMargins(16,0,16,85)
        root.addView(footer,fParams)
        setContentView(root)
        loadStyle()
    }
    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
}
