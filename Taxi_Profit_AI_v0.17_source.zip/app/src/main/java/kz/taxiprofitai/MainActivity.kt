package kz.taxiprofitai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** Local settings UI. No accounts, no servers, no payment APIs. */
class MainActivity: Activity() {
    private val prefs by lazy { getSharedPreferences("taxi_profit_settings",MODE_PRIVATE) }
    private val checks = linkedMapOf<String,CheckBox>()
    private lateinit var park: EditText
    private val yandexInputs=linkedMapOf<String,EditText>()
    private lateinit var loyalty: Spinner
    private lateinit var airport: CheckBox
    private lateinit var status: TextView
    private lateinit var refresh: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,26,22,32); setBackgroundColor(Color.rgb(247,249,249)) }
        fun title(t: String, size:Float=19f) { col.addView(TextView(this).apply {text=t;textSize=size;setTextColor(Color.BLACK);setPadding(0,14,0,6)}) }
        fun button(t:String,onClick:()->Unit) { col.addView(Button(this).apply {text=t;setOnClickListener{onClick()} }) }
        title("Taxi Profit AI",23f)
        title("Разрешения Android",17f)
        col.addView(TextView(this).apply { text="Разрешите службу специальных возможностей Taxi Profit AI. Она показывает радар поверх окон и читает доступный текст Яндекс Про. Отдельное разрешение SYSTEM_ALERT_WINDOW не требуется для этой реализации.";textSize=14f;setTextColor(Color.DKGRAY) })
        button("Открыть разрешения Android") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("OK · ЗАПУСТИТЬ РАДАР") {
            if(!save())return@button
            if(checks.values.none{it.isChecked}){Toast.makeText(this,"Выберите хотя бы один тариф",Toast.LENGTH_SHORT).show();return@button}
            if(!accessibilityEnabled()){
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this,"Включите Taxi Profit AI и вернитесь, чтобы нажать OK",Toast.LENGTH_LONG).show()
                return@button
            }
            prefs.edit().putBoolean("shift_active",true).apply()
            moveTaskToBack(true)
        }
        button("Завершить смену") { prefs.edit().putBoolean("shift_active",false).apply();Toast.makeText(this,"Радар и мониторинг остановлены",Toast.LENGTH_SHORT).show() }
        title("Отметь тарифы, на которых работаешь",17f)
        val selectedDefault=TarifCatalog.defaultSelected
        TarifCatalog.radarOrder.forEach {name ->
            val c=CheckBox(this).apply {text="${TarifCatalog.shortName(name)} · $name";isChecked=prefs.getBoolean("tariff_$name", name in selectedDefault)}
            checks[name]=c; col.addView(c)
        }
        col.addView(TextView(this).apply {
            text="Обозначения на панели: EK Эконом · K Комфорт · K+ Комфорт+ · EV Электро · BS Business · PR Premier"
            textSize=13f; setTextColor(Color.DKGRAY)
        })
        airport=CheckBox(this).apply {text="✈ Столбец «Аэропорт Алматы» в радаре";isChecked=prefs.getBoolean("airport",true)}
        col.addView(airport)
        title("Комиссия твоего таксопарка, %",16f)
        park=EditText(this).apply {setSingleLine(true); inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(prefs.getString("park","1"))}
        col.addView(park)
        col.addView(TextView(this).apply {
            text="Установи свой процент (например, 0; 1; 1,5; 2; 3). Он сохраняется и отдельно вычитается из прогнозной цены. Большая зелёная цифра «НА РУКИ» уже учитывает и Яндекс, и таксопарк."
            textSize=13f;setTextColor(Color.DKGRAY)
        })
        title("Комиссия Яндекса по каждому тарифу, %",17f)
        col.addView(TextView(this).apply {
            text="По данным Яндекс Про, сообщённым пользователем: EK — 17,1% с НДС; K, K+, BS — 19,2% с НДС. EV и PR — пока рабочие 19,2%, требуют проверки в Яндекс Про. НДС уже учтён: второй раз не прибавляем. Любой процент можно исправить вручную."
            textSize=13f;setTextColor(Color.DKGRAY)
        })
        TarifCatalog.radarOrder.forEach {name ->
            val profile=CommissionCatalog.forTariff(name)
            val row=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(TextView(this).apply {
                text="${TarifCatalog.shortName(name)} · $name";textSize=15f;setTextColor(Color.BLACK)
            },LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
            val field=EditText(this).apply {
                setSingleLine(true)
                inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                hint="нет данных"
                setText(CommissionSettings.percent(prefs,name)?.toString()?:"")
                textSize=16f;gravity=Gravity.END
            }
            yandexInputs[name]=field
            row.addView(field,LinearLayout.LayoutParams((90*resources.displayMetrics.density+0.5f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT))
            col.addView(row)
            col.addView(TextView(this).apply {
                text=if(CommissionSettings.wasEdited(prefs,name))"Введено вручную · перепроверь при смене условий"
                else when(profile.evidence){
                    CommissionEvidence.OBSERVED_IN_RIDES -> "По реальным поездкам · не гарантировано для каждого заказа"
                    CommissionEvidence.USER_REPORTED -> "По данным водителя · сверяй при изменении условий"
                    CommissionEvidence.PROVISIONAL -> "Предварительный ориентир, не подтверждён для тарифа"
                    CommissionEvidence.UNKNOWN -> "Неизвестно: ввести из детализации поездки"
                }
                textSize=11f;setTextColor(Color.DKGRAY
                );setPadding(0,0,0,6)
            })
        }
        title("Скидка на комиссию Яндекса",16f)
        loyalty=Spinner(this)
        loyalty.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,
            listOf("Без скидки","Чемпион −3 п.п.","Легенда −8 п.п."))
        loyalty.setSelection(when(CommissionSettings.loyalty(prefs)){3.0->1;8.0->2;else->0})
        col.addView(loyalty)
        col.addView(TextView(this).apply {
            text="Скидку указывай по фактическому уровню Яндекс Про. При отметке «Очень высокий спрос. Комиссия снижена» приложение уменьшит комиссионную базу по опубликованному правилу. Комиссия парка — отдельно."
            textSize=12f;setTextColor(Color.DKGRAY)
        })
        title("Обновление видимых отметок радара",16f)
        refresh=Spinner(this)
        val times=listOf("5 секунд","10 секунд","30 секунд")
        refresh.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,times)
        refresh.setSelection(when(prefs.getInt("interval",10)){5->0;30->2;else->1})
        col.addView(refresh)
        title("Карта",16f)
        col.addView(TextView(this).apply {
            text="Плоская карта: дороги, улицы и вода. Без гостиниц, достопримечательностей, зданий и 3D. Живые зоны без источника не рисуем."
            textSize=14f; setTextColor(Color.DKGRAY)
        })
        button("Открыть простую карту Алматы") { startActivity(Intent(this, SimpleMapActivity::class.java)) }
        title("Бесплатный маршрутизатор",16f)
        col.addView(TextView(this).apply {
            text="Требуется бесплатное приложение BRouter и загруженные дорожные сегменты .rd5 для Алматы. Расчёт без живых пробок. Адреса ищутся через геокодер Android (доступность не гарантирована)."
            textSize=14f;setTextColor(Color.DKGRAY)
        })
        button("Все 9 поездок: точность и журнал прогнозов") { startActivity(Intent(this, BenchmarkActivity::class.java)) }
        button("Проверить маршрут через BRouter") { if(save())startActivity(Intent(this, RouteTestActivity::class.java)) }
        button("Установить BRouter через F-Droid") {
            startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://f-droid.org/packages/btools.routingapp/")))
        }
        button("Сохранить настройки") { if(save()) Toast.makeText(this,"Сохранено локально",Toast.LENGTH_SHORT).show() }
        button("Включить чтение видимой карточки и накладку") {
            if(!save())return@button
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this,"В настройках Android включите службу Taxi Profit AI",Toast.LENGTH_LONG).show()
        }
        button("Показать результаты тестового расчёта") { if(save()) showTest() }
        title("Актуальность тарифов",16f)
        col.addView(TextView(this).apply {
            text=if(TarifCatalog.expiredToday()) "ВНИМАНИЕ: опубликованные ставки проезда исторические (24.11.2026), перепроверь перед реальными заказами."
                else "Опубликованные ставки проезда: 24.11.2026. Комиссии указаны отдельно, с учётом НДС."
            textSize=14f; setTextColor(Color.rgb(137,66,25))
        })
        title("Статус",16f)
        status=TextView(this).apply {text="Радар работает только с реально доступными показаниями.\nТочных коэффициентов всех тарифов без источника данных нет.\nBRouter подключается через Android Service, без платного API.\nЦель 2 секунды: пока не подтверждена тестом.";textSize=14f; setTextColor(Color.DKGRAY)}
        col.addView(status)
        scroll.addView(col)
        setContentView(scroll)
    }
    private fun accessibilityEnabled():Boolean {
        val am=getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        return am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            val info=it.resolveInfo.serviceInfo
            info.packageName==packageName && info.name==RadarAccessibilityService::class.java.name
        }
    }
    private fun save(): Boolean {
        fun valid(s:String) = s.replace(',','.').toDoubleOrNull()?.takeIf{it in 0.0..100.0}
        val p=valid(park.text.toString())
        val perTariff=yandexInputs.mapValues {(_,input) ->
            val raw=input.text.toString().trim()
            if(raw.isBlank())null else valid(raw)
        }
        val invalid=yandexInputs.any{(name,input)-> input.text.toString().isNotBlank() && perTariff[name]==null}
        if (p==null || invalid || perTariff.values.any{it!=null && it + p > 100.0}) {
            Toast.makeText(this,"Проверь проценты Яндекса и таксопарка",Toast.LENGTH_LONG).show();return false
        }
        prefs.edit().apply {
            checks.forEach{(name,c)->putBoolean("tariff_$name",c.isChecked)}
            putBoolean("airport",airport.isChecked)
            putString("park",p.toString())
            perTariff.forEach{(name,pct)->
                // Defaults remain marked as provisional unless actually changed.
                if(CommissionSettings.wasEdited(prefs,name) ||
                   pct!=CommissionCatalog.forTariff(name).referencePct) {
                    CommissionSettings.save(this,name,pct)
                }
            }
            putInt("loyalty_discount",when(loyalty.selectedItemPosition){1->3;2->8;else->0})
            putInt("interval",when(refresh.selectedItemPosition){0->5;2->30;else->10})
        }.apply()
        return true
    }
    private fun showTest() {
        val p=prefs.getString("park","1")!!.toDouble()
        val y=CommissionSettings.percent(prefs,"Business")
        if(y==null){Toast.makeText(this,"Укажи комиссию Business",Toast.LENGTH_LONG).show();return}
        val q=FareEngine.quote(TarifCatalog.businessReference,
            RouteEstimate(11.0,19.0),RouteEstimate(14.5,24.0),Demand(DemandType.MULTIPLIER,1.0,true),y,p,"ДВА ПРЕДПОЛОЖЕНИЯ — НЕ РЕАЛЬНЫЕ МАРШРУТЫ")
        android.app.AlertDialog.Builder(this).setTitle("Проверка математики — тест №3")
            .setMessage("Первый расчёт: 2 934 ₸\nВторой: 3 634,50 ₸\nСреднее: ${FareEngine.kzt(q.mean)}\nДоход после заданных комиссий: ${FareEngine.kzt(q.driverEstimate)}\n\nВажно: это исторический тест. В живых заказах цену без маршрута приложение НЕ выдумывает.")
            .setPositiveButton("Понятно",null).show()
    }
}
