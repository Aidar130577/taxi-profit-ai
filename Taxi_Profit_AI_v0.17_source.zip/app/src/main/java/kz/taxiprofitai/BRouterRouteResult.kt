package kz.taxiprofitai

/** Independently testable reader of BRouter's GeoJSON track properties. */
data class OfflineRoute(val km: Double, val minutes: Double, val source: String = "BRouter • без живых пробок")
object BRouterRouteResult {
    // Exact keys emitted by BRouter FormatJson: track-length (metres), total-time (seconds).
    private val distancePattern = Regex("\"track-length\"\\s*:\\s*\"?(\\d+(?:\\.\\d+)?)\"?")
    private val timePattern = Regex("\"total-time\"\\s*:\\s*\"?(\\d+(?:\\.\\d+)?)\"?")
    fun parse(raw: String): OfflineRoute {
        require(raw.trimStart().startsWith("{")) { "BRouter: ${raw.take(140)}" }
        require(raw.contains("FeatureCollection")) { "Ответ не похож на маршрут BRouter" }
        val metres = distancePattern.find(raw)?.groupValues?.get(1)?.toDoubleOrNull()
            ?: error("BRouter не вернул track-length")
        val seconds = timePattern.find(raw)?.groupValues?.get(1)?.toDoubleOrNull()
            ?: error("BRouter не вернул total-time")
        require(metres.isFinite() && metres in 50.0..500_000.0) { "Некорректная длина маршрута" }
        require(seconds.isFinite() && seconds in 1.0..100_000.0) { "Некорректная длительность маршрута" }
        return OfflineRoute(metres / 1000.0, seconds / 60.0)
    }
}
