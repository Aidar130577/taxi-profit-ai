#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/local-tests
kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        core-tests/EngineCheck.kt -include-runtime -d build/local-tests/engine.jar
java -jar build/local-tests/engine.jar
kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        core-tests/RoutingCheck.kt -include-runtime -d build/local-tests/routing.jar
java -jar build/local-tests/routing.jar

kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        app/src/main/java/kz/taxiprofitai/BenchmarkLedger.kt \
        core-tests/BenchmarkCheck.kt -include-runtime -d build/local-tests/benchmarks.jar
java -jar build/local-tests/benchmarks.jar

kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        core-tests/ExtrasCheck.kt -include-runtime -d build/local-tests/extras.jar
java -jar build/local-tests/extras.jar

kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        core-tests/TaxiScopeCheck.kt -include-runtime -d build/local-tests/scope.jar
java -jar build/local-tests/scope.jar

# No Android SDK required: stand-alone commission engine tests.
kotlinc app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        core-tests/CommissionCheck.kt -include-runtime -d build/local-tests/commission.jar
java -jar build/local-tests/commission.jar

# Visual radar table paging, six-tariff layout.
kotlinc app/src/main/java/kz/taxiprofitai/RadarPanelModel.kt \
        core-tests/RadarPanelCheck.kt -include-runtime -d build/local-tests/radar.jar
java -jar build/local-tests/radar.jar

# Pure state-machine test: dismissal is per order, not per UI event.
kotlinc app/src/main/java/kz/taxiprofitai/OfferPopupState.kt \
        core-tests/OfferPopupCheck.kt -include-runtime -d build/local-tests/popup.jar
java -jar build/local-tests/popup.jar

# Take-home after BOTH fees, editable taxi park and display formatting.
kotlinc app/src/main/java/kz/taxiprofitai/Engine.kt \
        app/src/main/java/kz/taxiprofitai/CommissionCatalog.kt \
        app/src/main/java/kz/taxiprofitai/BRouterRouteResult.kt \
        app/src/main/java/kz/taxiprofitai/NetQuotePresentation.kt \
        core-tests/NetPopupCheck.kt -include-runtime -d build/local-tests/net-popup.jar
java -jar build/local-tests/net-popup.jar
