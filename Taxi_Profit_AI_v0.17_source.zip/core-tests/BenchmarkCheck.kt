import kz.taxiprofitai.*
import kotlin.math.abs
fun closeTest(actual: Double, expected: Double, eps: Double = 0.015) = check(abs(actual-expected)<eps) { "got $actual expected $expected" }
fun main() {
  check(BenchmarkLedger.trips.size == 9)
  check(BenchmarkLedger.stats().count == 8)
  check(BenchmarkLedger.stats(false).count == 9)
  check(BenchmarkLedger.trips.count { it.state == ActualState.SCREEN_ONLY } == 1)
  closeTest(BenchmarkLedger.trips[8].absolutePercentError, 36.5/4090*100)
  closeTest(BenchmarkLedger.trips[4].absolutePercentError, 72.0/1580*100)
  closeTest(BenchmarkLedger.trips[6].absolutePercentError, 260.0/930*100)
  closeTest(BenchmarkLedger.stats().meanAbsolutePercentError, 15.2333642199139)
  closeTest(BenchmarkLedger.stats(false).meanAbsolutePercentError, 15.4502756410689)
  check(BenchmarkLedger.bestConfirmed(1).single().number == 9)
  check(BenchmarkLedger.trips[2].variants.last().beforeActual == false)
  check(BenchmarkLedger.trips[3].variants.last().beforeActual == false)
  check(BenchmarkLedger.trips[4].variants.single().forecast == 1793.0)
  check(BenchmarkLedger.trips[5].variants.single().forecast == 2243.1)
  println("OK benchmark ledger and leakage checks")
}
