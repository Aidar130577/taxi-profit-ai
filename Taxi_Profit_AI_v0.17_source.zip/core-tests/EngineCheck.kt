import kz.taxiprofitai.*
import kotlin.math.abs
fun checkNear(a:Double,b:Double)=check(abs(a-b)<0.001){"$a != $b"}
fun main(){
    val b=TarifCatalog.businessReference
    checkNear(FareEngine.base(b,RouteEstimate(11.0,19.0)),2934.0)
    checkNear(FareEngine.base(b,RouteEstimate(14.5,24.0)),3634.5)
    checkNear(FareEngine.quote(b,RouteEstimate(11.0,19.0),RouteEstimate(14.5,24.0),Demand(DemandType.MULTIPLIER,1.0,true),19.6,1.0,"manual").mean,3284.25)
    val d=OrderTextParser.parse("Пропустить\n1,7 км • 6 мин\nBusiness\nПринять ×1.00\nАлматы Аэропорт")
    check(d.order);check(d.tariff=="Business");check(d.demand!!.type==DemandType.MULTIPLIER);check(d.airport)
    val d2=OrderTextParser.parse("Пропустить\nКомфорт+\nПринять +800 ₸\nА улица Кунаева, 119\nБ Бесагаш")
    check(d2.order);check(d2.demand!!.amount==800.0);check(d2.pickup=="улица Кунаева, 119")
    val cache=RadarMemory();cache.put(RadarObservation("Business","+800 ₸",1000,"test",false))
    check(cache.current("Business",false,10000)!=null)
    check(cache.current("Business",false,40000)==null)
    val priorityOnly = OrderTextParser.parse("Пропустить\nBusiness\n+1\nПринять\nБез спроса")
    check(priorityOnly.demand == null) // loyalty/priority +1 is NOT +1 tenge
    println("OK 13 core checks")
}
