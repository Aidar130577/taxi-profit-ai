package kz.taxiprofitai

import kotlin.math.abs
private var n=0
private fun ok(v:Boolean, msg:String){check(v){msg};n++}
private fun approx(v:Double?,e:Double){ok(v!=null && abs(v-e)<0.005,"expected $e got $v")}
fun main(){
    val rate=TarifCatalog.forName("Business")!!
    val route=OfflineRoute(2.5,8.0,"synthetic")
    for(park in listOf(0.0,1.0,1.5,2.0,3.0,4.25)) {
        val est=RouteFareEstimator.calculateWithCommission(rate,route,Demand(DemandType.NONE),19.2,park)
        val expected=est.gross*(1.0-(19.2+park)/100.0)
        approx(est.net,expected)
        val u=NetQuotePresenter.present(est,park)
        ok(u.netKnown,"net computed at $park")
        ok(u.takeHomeText.startsWith("≈ ") && u.takeHomeText.endsWith(" ₸"),"net emphasized")
        ok(u.commissionLine.contains("Яндекс 19,2%"),"Yandex fee visible")
        ok(u.commissionLine.contains("парк "),"park fee visible")
    }
    val est=RouteFareEstimator.calculateWithCommission(rate,route,Demand(DemandType.NONE),19.2,1.5)
    val text=NetQuotePresenter.present(est,1.5)
    ok(text.commissionLine.contains("парк 1,5%"),"decimal park with comma")
    ok(text.grossText!=text.takeHomeText,"not gross or after-Yandex only")
    val noYandex=RouteFareEstimator.calculateWithCommission(rate,route,Demand(DemandType.NONE),null,1.0)
    val missing=NetQuotePresenter.present(noYandex,1.0)
    ok(!missing.netKnown && missing.takeHomeText=="—", "unknown commission does not invent take-home")
    ok(missing.commissionLine.contains("Яндекс —"), "unknown commission visibly marked")
    val pending=NetQuotePresenter.present(null,1.0)
    ok(pending.grossText=="—" && pending.takeHomeText=="—", "pending route cannot invent a value")
    val econ=TarifCatalog.forName("Эконом")!!
    val ek=RouteFareEstimator.calculateWithCommission(econ,route,Demand(DemandType.NONE),17.1,2.0)
    ok(NetQuotePresenter.present(ek,2.0).commissionLine.contains("Яндекс 17,1%"),"econom rate is distinct")
    val loyalty=RouteFareEstimator.calculateWithCommission(rate,route,Demand(DemandType.NONE),19.2,1.5,3.0)
    ok(NetQuotePresenter.present(loyalty,1.5).commissionLine.contains("Яндекс 16,2%"),"effective rather than base rate shown")
    println("Net fare popup: $n checks OK")
}
