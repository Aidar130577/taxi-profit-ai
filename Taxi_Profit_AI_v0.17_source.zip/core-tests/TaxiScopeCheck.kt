import kz.taxiprofitai.*
import java.time.LocalDate
fun main(){
 val desired=listOf("Эконом","Комфорт","Комфорт+","Электро","Business","Premier")
 check(TarifCatalog.titles==desired)
 check(TarifCatalog.shortLabels==mapOf("Эконом" to "EK","Комфорт" to "K","Комфорт+" to "K+","Электро" to "EV","Business" to "BS","Premier" to "PR"))
 check(TarifCatalog.radarOrder.size==6 && TarifCatalog.radarOrder.toSet()==desired.toSet())
 listOf("Водитель","Межгород","Вместе","Доставка","Курьер","Грузовой","Грузовой Межгород","Яндекс Еда").forEach {
   check(TarifCatalog.forName(it)==null)
   check(OrderTextParser.parse("Пропустить\n$it\nПринять +600 ₸").tariff==null)
 }
 check(TarifCatalog.forName("Premier")!=null)
 check(!TarifCatalog.rateExpired("Business",LocalDate.parse("2026-11-24")))
 check(TarifCatalog.rateExpired("Business",LocalDate.parse("2026-11-25")))
 val order=OrderTextParser.parse("Пропустить\n2,2 км • 4 мин\nКомфорт+\nА\nул Абая 10\nБ\nул Толе би 11\nПринять +800 ₸")
 check(order.tariff=="Комфорт+" && order.demand?.amount==800.0)
 println("OK taxi-only scope: 6 tariffs, short names, excluded categories, expiry and order parsing")
}
