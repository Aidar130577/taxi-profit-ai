import kz.taxiprofitai.*
fun main(){
 val all=listOf("EK","K","K+","EV","BS","PR").map{RadarPanelRow(it,"+500 ₸","—")}
 check(RadarPanelModel.visible(all,all.map{it.tariff}.toSet()).size==6)
 check(RadarPanelModel.visible(all,setOf("EV","BS")).map{it.tariff}==listOf("EV","BS"))
 check(RadarPanelModel.height(6)==205f)
 check(RadarPanelModel.height(2)==105f)
 check(RadarPanelModel.visible(all,emptySet()).isEmpty())
 check(RadarPanelModel.display("×1,2",false)=="—")
 check(RadarPanelModel.display("+500 ₸",false)=="+500 ₸")
 check(RadarPanelModel.display("+800 ₸",true)=="~+800 ₸")
 check(RadarPanelModel.display("—",true)=="—")
 println("RadarPanelCheck: 9 assertions OK")
}
