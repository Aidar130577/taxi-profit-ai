import kz.taxiprofitai.*
import kotlin.math.abs
private var tests=0
private fun near(a:Double?,b:Double) {check(a!=null && abs(a-b)<0.005) {"expected=$b actual=$a"};tests++}
private fun good(v:Boolean){check(v);tests++}
fun main(){
 val names=listOf("Эконом","Комфорт","Комфорт+","Электро","Business","Premier")
 good(CommissionCatalog.profiles.map{it.tariff}==names)
 near(CommissionCatalog.forTariff("Эконом").referencePct,17.1)
 names.drop(1).forEach{ near(CommissionCatalog.forTariff(it).referencePct,19.2) }
 good(CommissionCatalog.forTariff("Business").evidence==CommissionEvidence.OBSERVED_IN_RIDES)
 good(CommissionCatalog.forTariff("Premier").evidence==CommissionEvidence.PROVISIONAL)
 good(CommissionCatalog.forTariff("Электро").evidence==CommissionEvidence.PROVISIONAL)
 good(CommissionCatalog.forTariff("Комфорт").evidence==CommissionEvidence.USER_REPORTED)
 good(CommissionCatalog.forTariff("Комфорт+").evidence==CommissionEvidence.USER_REPORTED)
 good(runCatching { CommissionCatalog.forTariff("Водитель") }.isFailure)
 near(CommissionCatalog.effectiveRate(19.2,3.0),16.2)
 near(CommissionCatalog.effectiveRate(19.2,8.0),11.2)
 near(CommissionCatalog.effectiveRate(17.1,8.0),9.1)
 good(CommissionCatalog.effectiveRate(null,8.0)==null)
 // One VAT-inclusive commission rate, no extra VAT deduction.
 val vatIncluded=CommissionCatalog.calculate(1000.0,1000.0,17.1,1.0)
 near(vatIncluded.yandexFee,171.0)
 near(vatIncluded.net,819.0)
 // Six tariff profiles only. A deleted Driver profile must not be returned.
 for(name in names) {
     val rate=CommissionCatalog.forTariff(name).referencePct
     val expected=if(name=="Эконом")17.1 else 19.2
     near(rate,expected)
     val result=CommissionCatalog.calculate(1000.0,1000.0,rate,1.0)
     near(result.yandexFee,10.0*expected)
     near(result.net,990.0-10.0*expected)
 }
 // With no independent data, an explicit null still suppresses net (manual blank).
 good(CommissionCatalog.calculate(1000.0,1000.0,null,1.0).net==null)
 // Business: observed ~19.2%; park 1% separately, no second deduction of VAT.
 val bs=CommissionCatalog.calculate(1580.0,1330.0,19.2,1.0)
 near(bs.yandexFee,303.36);near(bs.parkFee,15.8);near(bs.net,1260.84)
 // Extreme-demand example from Yandex official docs: 600+750=1350, charge on 1200.
 val surge=CommissionCatalog.calculate(1350.0,600.0,19.2,1.0,
     verifiedHighDemandBanner=true)
 near(surge.yandexBase,1200.0);near(surge.yandexFee,230.4)
 good(surge.surgeExemptionApplied)
 val normal=CommissionCatalog.calculate(1350.0,600.0,19.2,1.0)
 near(normal.yandexBase,1350.0)
 good(!normal.surgeExemptionApplied)
 val cashback=CommissionCatalog.calculate(1350.0,600.0,19.2,1.0,
     loyaltyDiscountPoints=3.0, verifiedHighDemandBanner=true)
 near(cashback.effectiveYandexPct,16.2)
 // Passenger-fee exclusions ONLY when verified; park and Yandex bases differ from gross.
 val passThrough=CommissionCatalog.calculate(3410.0,3155.0,19.2,1.0,
     verifiedPassThroughFees=255.0)
 near(passThrough.yandexBase,3155.0);near(passThrough.parkFee,31.55)
 println("OK $tests commission/category/discount/surge checks")
}