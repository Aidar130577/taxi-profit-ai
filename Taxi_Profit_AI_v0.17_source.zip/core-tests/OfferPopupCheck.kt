package kz.taxiprofitai

private var passed=0
private fun ok(condition:Boolean,description:String){check(condition){description};passed++}
fun main(){
    val s=OfferPopupState()
    ok(!s.shouldShow(),"no popup when idle")
    val a=OfferPopupState.identity("Толе би, 157/12","Аэропорт Алматы","Business")
    ok(a!=null,"complete card identity")
    ok(a==OfferPopupState.identity("  толе  би, 157/12 "," Аэропорт Алматы "," BUSINESS "),"normalizes identity")
    s.observe(true,a)
    ok(s.shouldShow(),"first order appears")
    s.dismiss()
    ok(!s.shouldShow() && s.isDismissed(),"tap dismisses")
    s.observe(true,a)
    ok(!s.shouldShow(),"same card stays dismissed")
    s.observe(true,null)
    ok(!s.shouldShow(),"partial card cannot redisplay")
    s.observe(true,a)
    ok(!s.shouldShow(),"old order after partial remains dismissed")
    val b=OfferPopupState.identity("Абая, 160","Жандосова, 2","Комфорт+")
    s.observe(true,b)
    ok(s.shouldShow(),"genuinely new order resets dismissed")
    s.dismiss()
    s.observe(false)
    ok(!s.shouldShow() && !s.isDismissed(),"offer gone clears state")
    s.observe(true,b)
    ok(s.shouldShow(),"new occurrence of same route can be shown")
    ok(OfferPopupState.identity(null,"Аэропорт","Business")==null,"null pickup no identity")
    ok(OfferPopupState.identity("А","Б",null)==null,"null tariff no identity")
    println("OfferPopup: $passed checks OK")
}
