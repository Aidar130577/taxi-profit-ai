import kz.taxiprofitai.*
import kotlin.math.abs
private var checks = 0
private fun close(a:Double,b:Double,eps:Double=0.001) {check(abs(a-b)<eps){"Expected $b got $a"};checks++}
private fun yes(value:Boolean) {check(value);checks++}
private fun fails(block:()->Unit) {try {block()}catch(_:Exception){checks++;return};error("Expected failure")}
fun main() {
  val json="""{"type":"FeatureCollection","features":[{"type":"Feature","properties":{"creator":"BRouter","track-length":"1840","total-time":"360"},"geometry":{"type":"LineString","coordinates":[[76.9,43.2],[76.91,43.21]]}}]}"""
  val route=BRouterRouteResult.parse(json)
  close(route.km,1.84);close(route.minutes,6.0)
  val noQuotes="""{"type":"FeatureCollection","features":[{"properties":{"track-length":2500,"total-time":420}}]}"""
  close(BRouterRouteResult.parse(noQuotes).km,2.5)
  fails{BRouterRouteResult.parse("Route not found")}
  fails{BRouterRouteResult.parse("{\"type\":\"FeatureCollection\",\"track-length\":\"0\",\"total-time\":\"10\"}")}
  fails{BRouterRouteResult.parse("{\"type\":\"FeatureCollection\",\"track-length\":\"9999999\",\"total-time\":\"10\"}")}
  yes(TarifCatalog.titles.size==6)
  val r = TarifCatalog.forName("Комфорт+")!!
  close(FareEngine.base(r,RouteEstimate(2.0,4.0)),717.0)
  close(FareEngine.applyDemand(717.0,Demand(DemandType.FIXED_ADD,250.0,true)),967.0)
  val quote=RouteFareEstimator.calculate(r, OfflineRoute(2.0,4.0),Demand(DemandType.FIXED_ADD,250.0,true),19.2,1.0)
  close(quote.gross,967.0);close(quote.net!!,771.666)
  close(FareEngine.base(r,RouteEstimate(1.0,3.0)),595.0)
  val c=TarifCatalog.forName("Premier")!!
  close(FareEngine.base(c,RouteEstimate(1.0,3.0)),1170.0)
  close(FareEngine.base(c,RouteEstimate(2.0,4.0)),1405.0)
  val split = OrderTextParser.parse("Пропустить\n2,2 км • 4 мин\nКомфорт+\nА\nулица Ораза Жандосова, 2Б\nБ\nулица Ади Шарипова, 72\nПринять +250 ₸")
  yes(split.order);yes(split.tariff=="Комфорт+")
  yes(split.pickup=="улица Ораза Жандосова, 2Б")
  yes(split.destination=="улица Ади Шарипова, 72")
  close(split.demand!!.amount,250.0)
  val noDouble=OrderTextParser.parse("Пропустить\nBusiness\n+1\nПринять ×1.00")
  yes(noDouble.demand!!.type==DemandType.MULTIPLIER)
  close(noDouble.demand!!.amount,1.0)
  val meter=TarifCatalog.forName("Эконом")!!
  close(FareEngine.base(meter,RouteEstimate(3.0,8.0)),651.0)
  println("OK $checks routing/fare/parser checks")
}
