import kz.taxiprofitai.*
import kotlin.math.abs
fun near(a: Double, b: Double) = check(abs(a-b)<0.001){ "$a != $b" }
fun main() {
 val business=TarifCatalog.forName("Business")!!
 val trip=RouteEstimate(2.0,4.0)
 val demand=Demand(DemandType.FIXED_ADD,250.0,true)
 val baseline=FareEngine.detailed(business,trip,demand)
 near(baseline.ride,1017.0)
 near(baseline.demand,250.0)
 near(baseline.gross,1267.0)
 near(baseline.waiting,0.0)
 val unverified=FareEngine.detailed(business,trip,demand,ConfirmedExtras(
  paidWaitingMinutes=3.0,waitRate=80.0,pickupCharge=285.0,airportCharge=265.0))
 near(unverified.gross,baseline.gross)
 val waitOnly=FareEngine.detailed(business,trip,demand,ConfirmedExtras(
  paidWaitingMinutes=3.0,waitRate=80.0,paidWaitingConfirmed=true))
 near(waitOnly.gross,baseline.gross+240.0)
 val paidOnly=FareEngine.detailed(business,trip,demand,ConfirmedExtras(
  pickupCharge=285.0,paidPickupConfirmed=true,airportCharge=265.0,airportChargeConfirmed=true))
 near(paidOnly.gross,baseline.gross+550.0)
 near(FareEngine.applyDemand(1017.0,Demand(DemandType.FIXED_ADD,250.0,false)),1017.0)
 near(FareEngine.applyDemand(1017.0,Demand(DemandType.MULTIPLIER,1.5,false)),1017.0)
 near(FareEngine.applyDemand(1017.0,Demand(DemandType.MINIMUM_BONUS,800.0,true)),1017.0)
 near(FareEngine.applyDemand(1017.0,Demand(DemandType.MULTIPLIER,1.0,true)),1017.0)
 check(TarifCatalog.expiredToday(java.time.LocalDate.parse("2026-11-25")))
 check(!TarifCatalog.expiredToday(java.time.LocalDate.parse("2026-11-24")))
 println("OK verified-only extras / freshness checks")
}
